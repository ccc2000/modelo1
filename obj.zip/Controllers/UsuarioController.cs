﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WFComercialWebApp.Models;
using Bitacora;
using NLog;
using System.Data.Entity.Validation;

namespace WFComercialWebApp.Controllers
{
    public class UsuarioController : Controller
    {
        private RiesgosComercialesEntities db = new RiesgosComercialesEntities();

        // GET: /Usuario/
        public ActionResult Index()
        {
            return View(db.Usuario.ToList());
        }

        // GET: /Usuario/Details/5
        public ActionResult Details(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Usuario usuario = db.Usuario.Find(id);
                if (usuario == null)
                {
                    return HttpNotFound();
                }
                return View(usuario);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Details ", ex);
                return null;
                throw;
            }
        }

        // GET: /Usuario/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: /Usuario/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "UsuarioID,Nombre,Matricula,Cargo")] Usuario usuario)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create " + usuario.Matricula.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                    db.Usuario.Add(usuario);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                return View(usuario);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create POST ", ex);
                return null;
                throw;
            }
        }

        // GET: /Usuario/Edit/5
        public ActionResult Edit(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Usuario usuario = db.Usuario.Find(id);
                if (usuario == null)
                {
                    return HttpNotFound();
                }
                return View(usuario);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit ", ex);
                return null;
                throw;
            }
        }

        // POST: /Usuario/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "UsuarioID,Nombre,NombreUsuario, Matricula,Cargo, Correo_auxiliar")] Usuario usuario, string IsChecked)
        {
            try
            {
                GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit " + usuario.Matricula.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                if (ModelState.IsValid)
                {
                    if (IsChecked == "Activado")
                    {
                        usuario.Flag_Correo_auxiliar = 1;
                    }
                    else {
                        usuario.Flag_Correo_auxiliar = 0;
                    }

                    db.Entry(usuario).State = EntityState.Modified;
                    db.SaveChanges();
                    //return RedirectToAction("Index");
                    return RedirectToAction("Index", "Operacion");
                }
                return View(usuario);
            }
            //catch (Exception ex)
            //{
            //    GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit POST ", ex);
            //    return null;
            //    throw;
            //}
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        // GET: /Usuario/Delete/5
        public ActionResult Delete(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Usuario usuario = db.Usuario.Find(id);
                if (usuario == null)
                {
                    return HttpNotFound();
                }
                return View(usuario);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Delete ", ex);
                return null;
                throw;
            }
        }

        // POST: /Usuario/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - DeleteConfirmed " + id.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                Usuario usuario = db.Usuario.Find(id);
                db.Usuario.Remove(usuario);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - DeleteConfirmed ", ex);
                return null;
                throw;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
