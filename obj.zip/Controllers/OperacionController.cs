﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WFComercialWebApp.Models;
using Bitacora;
using NLog;
using System.Net.Http;
using Microsoft.Office.Interop;
using System.IO;
//Microsoft.Office.Interop

namespace WFComercialWebApp.Controllers
{
    public class OperacionController : Controller
    {
        private RiesgosComercialesEntities db = new RiesgosComercialesEntities();
        int id_user = 34;
        //86 -> Funcionario de Negocios AArce
        //94 -> gerente de Negocios CL
        //16 -> gerente de Riesgos RC
        //71 -> funcionario de Riesgos YG
        //38 -> Auxiliar de Riesgos GE

        public static string geturl()
        {
            string _urlapi = "";
            //return "http://localhost:5000/api";
            return "http://172.31.111.229:50005/api";
        }

        // GET: /Operacion/
        public ActionResult Index()
        {
            try
            {
                GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Inicio de session " + User.Identity.Name.ToUpper().Substring(7));
                // Buscamos al usuario logueado
                Usuario usuario = db.Usuario.First(u => u.NombreUsuario == User.Identity.Name.ToUpper().Substring(7));
                usuario = db.Usuario.Find(id_user);
                ViewBag.cargoUsuario = usuario.Cargo;
                ViewBag.usuario = usuario;
                ViewBag.id_usuario = usuario.UsuarioID;

                var operacion = db.Operacion.Include(o => o.Cliente).Include(o => o.Estado).Where(o => o.Seguimiento.Any(s => s.Usuario1.Any(u => u.UsuarioID == usuario.UsuarioID) || s.UsuarioID == usuario.UsuarioID)).Distinct();
                //var operacion = db.Operacion.Include(o => o.Cliente).Include(o => o.Estado).Join(db.Seguimiento.Where(s => s.Usuario1.Where(u => u.UsuarioID == usuario.UsuarioID)));
                //var operacion = db.Operacion.Include(o => o.Cliente).Include(o => o.Estado).Join(db.Seguimiento, s => s.OperacionID, o => o.OperacionID, (s, o) => new { s, o }).Select(o => new Operacion { });
                //var operacion = db.Seguimiento.Include(s => s.Usuario1.Where( u => u.UsuarioID == usuario.UsuarioID ));
                //foreach (var item in operacion.ToList())
                //{
                //    var _test = item.Seguimiento.Where(s => s.Asunto == "Evaluación Riesgos" && (s.Usuario1.Contains(usuario) || s.Usuario == usuario)).Count();
                //    var alt = item.Seguimiento.Where(s => s.Asunto == "Evaluación Riesgos" && (s.Usuario1.Contains(ViewBag.usuario) || s.Usuario == ViewBag.usuario)).Last().PlazoVencimiento != 0 && ViewBag.cargoUsuario == "Funcionario de Negocios";
                //    if (( _test > 0 ? item.Seguimiento.Where(s => s.Asunto == "Evaluación Riesgos" && (s.Usuario1.Contains(ViewBag.usuario) || s.Usuario == ViewBag.usuario)).Last().PlazoVencimiento != 0 && ViewBag.cargoUsuario == "Funcionario de Negocios" : false))
                //    {
                //        string A = "2";
                //    }
                //}
                
                return View(operacion.ToList().OrderByDescending(o => o.Seguimiento.Last().Fecha));
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - INDEX", ex);
                return null;
                throw;
            }
        }

        public ActionResult Docs()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public FileResult DownloadFile(string path)
        {
            string _url = geturl();
            HttpClient client = new HttpClient();
            HttpResponseMessage response = client.GetAsync(_url + string.Format("/rsgs/download_file?path={0}", path)).Result;
            if (response.IsSuccessStatusCode)
            {
                return File(response.Content.ReadAsByteArrayAsync().Result, response.Content.Headers.ContentType.MediaType, Path.GetFileName(path));
                //return null;
            }
            return null;
        }

        public ActionResult Operaciones_Baja()
        {
            var _list_op = (from a in db.Operacion
                            where a.EstadoID.Equals(20)
                            join b in db.Cliente on a.ClienteID equals b.ClienteID
                            join c in db.Estado on a.Estado_Baja equals c.EstadoID
                            select new { a.OperacionID, a.Fecha_Baja, b.Nombre, a.Tipo, Estado = c.Nombre, a.Banca, a.Region }).ToList();

            var model = _list_op.Select(x => new List_Ope_Model
            {
                OperacionID = x.OperacionID.ToString(),
                Fecha = Convert.ToDateTime(x.Fecha_Baja.Substring(6, 2) + "/" + x.Fecha_Baja.Substring(4, 2) + "/" + x.Fecha_Baja.Substring(0, 4)).ToString().Substring(0,10),
                Cliente = x.Nombre,
                Tipo = x.Tipo,
                Estado = x.Estado,
                Banca = x.Banca,
                Region = x.Region                
            }).ToList();

            return View(model);
        }

        // GET: /Operacion/Details/5
        public ActionResult Details(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Operacion operacion = db.Operacion.Find(id);
                if (operacion == null)
                {
                    return HttpNotFound();
                }
                return View(operacion);

            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Details ", ex);
                return null;
                throw;
            }
        }


        [ChildActionOnly]
        public PartialViewResult _ViewOperacion(int OperacionID)
        {
            try
            {
                Operacion operacion = db.Operacion.Find(OperacionID);
                var usuarioLogueado = (from p in db.Usuario
                                       where p.NombreUsuario == "RCU4" && p.Cargo == "Gerente de Riesgos"
                                   select p).ToList();
                
                if (usuarioLogueado.Count() > 0)
                {
                    ViewBag.btn_baja = "1";
                }
                else {
                    ViewBag.btn_baja = "0";
                }

                return PartialView(operacion);

            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - _ViewOperacion ", ex);
                return null;
                throw;
            }
        }


        // GET: /Operacion/Create
        public ActionResult Create(string message = "")
        {
            try
            {
                ViewBag.msg = message;
                ViewBag.ClienteID = new SelectList(db.Cliente, "ClienteID", "Nombre");
                //ViewBag.EstadoID = new SelectList(db.Estado, "EstadoID", "Nombre");
                return View();

            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create ", ex);
                return null;
                throw;
            }
        }

        // POST: /Operacion/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "OperacionID,ClienteID, Banca, Region, Sucursal")] Operacion operacion)
        {
            try
            {
                GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create " + operacion.OperacionID.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                // Establecemos los parametros iniciales
                operacion.EstadoID = 1; // estado inicial = "Evaluación Negocios"
                operacion.Tipo = "";
                operacion.CEM = 0;

                //operacion.Banca = "";
                //operacion.Region = "";
                //operacion.Sucursal = "";

                if (ModelState.IsValid)
                {
                    //Verificamos que el cliente no tenga operaciones en curso
                    int _idcliente = operacion.ClienteID;
                    Operacion _opeaux = db.Operacion.FirstOrDefault(u => u.ClienteID == _idcliente && u.EstadoID != 20 && u.EstadoID < 17);
                    if (_opeaux !=  null)
                    {
                        return RedirectToAction("Create", "Operacion", new { message = "El cliente tiene operaciones en curso" });
                    }

                    db.Operacion.Add(operacion);
                    db.SaveChanges();

                    return RedirectToAction("CreateFirst", "Seguimiento", new { OperacionID = operacion.OperacionID });
                }

                ViewBag.ClienteID = new SelectList(db.Cliente, "ClienteID", "Nombre", operacion.ClienteID);
                //ViewBag.EstadoID = new SelectList(db.Estado, "EstadoID", "Nombre", operacion.EstadoID);
                return View(operacion);

            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create ", ex);
                return null;
                throw;
            }
        }

        // GET: /Operacion/Edit/5
        public ActionResult Edit(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Operacion operacion = db.Operacion.Find(id);
                if (operacion == null)
                {
                    return HttpNotFound();
                }
                ViewBag.ClienteID = new SelectList(db.Cliente, "ClienteID", "CIC", operacion.ClienteID);
                ViewBag.EstadoID = new SelectList(db.Estado, "EstadoID", "Nombre", operacion.EstadoID);
                return View(operacion);

            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit ", ex);
                return null;
                throw;
            }
        }

        // POST: /Operacion/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "OperacionID,EstadoID,Tipo,ClienteID,CEM")] Operacion operacion)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit " + operacion.OperacionID.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                    db.Entry(operacion).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                ViewBag.ClienteID = new SelectList(db.Cliente, "ClienteID", "CIC", operacion.ClienteID);
                ViewBag.EstadoID = new SelectList(db.Estado, "EstadoID", "Nombre", operacion.EstadoID);
                return View(operacion);

            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit  ", ex);
                return null;
                throw;
            }
        }

        // GET: /Operacion/Delete/5
        public ActionResult Delete(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Operacion operacion = db.Operacion.Find(id);
                if (operacion == null)
                {
                    return HttpNotFound();
                }
                return View(operacion);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Delete ", ex);
                return null;
                throw;
            }
        }

        // POST: /Operacion/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - DeleteConfirmed " + id.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                Operacion operacion = db.Operacion.Find(id);
                db.Operacion.Remove(operacion);
                db.SaveChanges();
                return RedirectToAction("Index");

            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Delete ", ex);
                return null;
                throw;
            }
        }


        public ActionResult generateCheckList(int SeguimientoID, string rdbtn1, string rdbtn2, string rdbtn3, string rdbtn4, string rdbtn5, string rdbtn6, string rdbtn7, string rdbtn8, string rdbtn9, string rdbtn10, string rdbtn11, string rdbtn12, string rdbtn13, string rdbtn14, string rdbtn15, string rdbtn16, string rdbtn17, string rdbtn18, string rdbtn19, string rdbtn20, string otros_docu, string otros_docu2, string otros_docu_obs, string otros_docu_obs2, string rdbtn21, string rdbtn22, string rdbtn23, string rdbtn24, string rdbtn25, string rdbtn26, string rdbtn27, string rdbtn28, string otros_docu3, string otros_docu4, string otros_docu5, string otros_docu6)
        {
            try
            {
                string ruta = Server.MapPath("..\\Reportes\\");

                Operacion operacion = db.Seguimiento.Find(SeguimientoID).Operacion;
                var ffnn = operacion.Seguimiento.Where(u => u.Usuario.Cargo == "Funcionario de Riesgos" || u.Usuario.Cargo == "_Funcionario de Riesgos").Last();

                Microsoft.Office.Interop.Excel.Application objApp;
                Microsoft.Office.Interop.Excel.Workbook objBook;
                Microsoft.Office.Interop.Excel.Sheets objSheets;
                Microsoft.Office.Interop.Excel._Worksheet workSheet;
                Microsoft.Office.Interop.Excel.Range range;
                string plantilla_ori = ruta + @"Plantilla_CHECK_LIST.xlsx";
                string plantilla = string.Empty;
                string aux = string.Empty;
                
                if (!System.IO.File.Exists(ruta + "Plantilla_CHECK_LIST" + operacion.Cliente.Nombre + ".xlsx"))
                {
                    plantilla = ruta + "Plantilla_CHECK_LIST" + operacion.Cliente.Nombre + ".xlsx";
                    aux = ruta + "Plantilla_CHECK_LIST" + operacion.Cliente.Nombre + "_.xlsx";
                    System.IO.File.Copy(plantilla_ori, plantilla, true);
                }
                else
                {
                    string today = DateTime.Now.ToString("yyyyMMddHHmmss");
                    plantilla = ruta + "Plantilla_CHECK_LIST" + operacion.Cliente.Nombre + today + ".xlsx";
                    aux = ruta + "Plantilla_CHECK_LIST" + operacion.Cliente.Nombre + today + "_.xlsx";
                    System.IO.File.Copy(plantilla_ori, plantilla, true);
                }

                objApp = new Microsoft.Office.Interop.Excel.Application();
                objBook = objApp.Workbooks.Open(plantilla, 0, true, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, false, false);
                objSheets = objBook.Worksheets;
                workSheet = (Microsoft.Office.Interop.Excel.Worksheet)objSheets.get_Item(1);

                workSheet.Cells[3, 4] = "Nombre del Cliente: " + operacion.Cliente.Nombre;
                workSheet.Cells[4, 4] = "Funcionario de Negocios: " + ffnn.Usuario.Nombre;
                workSheet.Cells[5, 4] = "Matricula: " + ffnn.Usuario.Matricula;
                workSheet.Cells[5, 6] = "Ciudad: " + operacion.Sucursal;

                if (rdbtn1 != null)
                {if (rdbtn1 == "1A") { workSheet.Cells[9, 14] = "X"; } else { workSheet.Cells[9, 15] = "X"; }}
                if (rdbtn2 != null)
                {if (rdbtn2 == "2A") { workSheet.Cells[10, 14] = "X"; } else { workSheet.Cells[10, 15] = "X"; }}
                if (rdbtn3 != null)
                {if (rdbtn3 == "3A") { workSheet.Cells[11, 14] = "X"; } else { workSheet.Cells[11, 15] = "X"; }}
                if (rdbtn4 != null)
                {if (rdbtn4 == "4A") { workSheet.Cells[12, 14] = "X"; } else { workSheet.Cells[12, 15] = "X"; }}
                if (rdbtn5 != null)
                {if (rdbtn5 == "5A") { workSheet.Cells[13, 14] = "X"; } else { workSheet.Cells[13, 15] = "X"; }}
                if (rdbtn6 != null)
                {if (rdbtn6 == "6A") { workSheet.Cells[14, 14] = "X"; } else { workSheet.Cells[14, 15] = "X"; }}
                if (rdbtn7 != null)
                {if (rdbtn7 == "7A") { workSheet.Cells[15, 14] = "X"; } else { workSheet.Cells[15, 15] = "X"; }}
                if (rdbtn8 != null)
                {if (rdbtn8 == "8A") { workSheet.Cells[16, 14] = "X"; } else { workSheet.Cells[16, 15] = "X"; }}
                if (rdbtn9 != null)
                {if (rdbtn9 == "9A") { workSheet.Cells[17, 14] = "X"; } else { workSheet.Cells[17, 15] = "X"; }}
                if (rdbtn10 != null)
                {if (rdbtn10 == "10A") { workSheet.Cells[18, 14] = "X"; } else { workSheet.Cells[18, 15] = "X"; }}
                if (rdbtn11 != null)
                {if (rdbtn11 == "11A") { workSheet.Cells[19, 14] = "X"; } else { workSheet.Cells[19, 15] = "X"; }}
                if (rdbtn12 != null)
                {if (rdbtn12 == "12A") { workSheet.Cells[21, 14] = "X"; } else { workSheet.Cells[21, 15] = "X"; }}
                if (rdbtn13 != null)
                {if (rdbtn13 == "13A") { workSheet.Cells[23, 14] = "X"; } else { workSheet.Cells[23, 15] = "X"; }}
                if (rdbtn14 != null)
                {if (rdbtn14 == "14A") { workSheet.Cells[24, 14] = "X"; } else { workSheet.Cells[24, 15] = "X"; }}
                if (rdbtn15 != null)
                {if (rdbtn15 == "15A") { workSheet.Cells[26, 14] = "X"; } else { workSheet.Cells[26, 15] = "X"; }}
                if (rdbtn16 != null)
                {if (rdbtn16 == "16A") { workSheet.Cells[27, 14] = "X"; } else { workSheet.Cells[27, 15] = "X"; }}
                if (rdbtn17 != null)
                {if (rdbtn17 == "17A") { workSheet.Cells[29, 14] = "X"; } else { workSheet.Cells[29, 15] = "X"; }}
                if (rdbtn18 != null)
                {if (rdbtn18 == "18A") { workSheet.Cells[30, 14] = "X"; } else { workSheet.Cells[30, 15] = "X"; }}
                if (rdbtn19 != null)
                {if (rdbtn19 == "19A") { workSheet.Cells[32, 14] = "X"; } else { workSheet.Cells[32, 15] = "X"; }}
                if (rdbtn20 != null)
                {if (rdbtn20 == "20A") { workSheet.Cells[33, 14] = "X"; } else { workSheet.Cells[33, 15] = "X"; }}

                workSheet.Cells[35, 5] = otros_docu;
                workSheet.Cells[36, 5] = otros_docu2;
                workSheet.Cells[38, 4] = otros_docu_obs;
                workSheet.Cells[39, 4] = otros_docu_obs2;

                if (rdbtn21 != null)
                {workSheet.Cells[41, 15] = "X";}
                if (rdbtn22 != null)
                {workSheet.Cells[42, 15] = "X";}
                if (rdbtn23 != null)
                {workSheet.Cells[43, 15] = "X";}
                if (rdbtn24 != null)
                {workSheet.Cells[44, 15] = "X";}
                if (rdbtn25 != null)
                {workSheet.Cells[45, 15] = "X";}
                if (rdbtn26 != null)
                {workSheet.Cells[46, 15] = "X";}
                if (rdbtn27 != null)
                {workSheet.Cells[47, 15] = "X";}
                if (rdbtn28 != null)
                {workSheet.Cells[48, 15] = "X";}

                workSheet.Cells[50, 4] = otros_docu3;
                workSheet.Cells[51, 4] = otros_docu4;
                workSheet.Cells[53, 4] = otros_docu5;
                workSheet.Cells[54, 4] = otros_docu6;

                objBook.SaveAs(aux);
                objBook.Close();

                var bytes = System.IO.File.ReadAllBytes(aux);
                return File(bytes, "application/vnd.ms-excel", "WF_Excepciones.xlsx");
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO TEST - REPORTE", ex);
                return null;
                throw;
            }
        }

        

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
