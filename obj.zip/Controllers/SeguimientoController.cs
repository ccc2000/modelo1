﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using WFComercialWebApp.Models;
using Bitacora;
using NLog;
using System.Security.AccessControl;
using System.Security;
using System.Web.Security;
using System.ComponentModel;
using System.Data.Entity.Validation;

namespace WFComercialWebApp.Controllers
{
    public class SeguimientoController : Controller
    {
        private RiesgosComercialesEntities db = new RiesgosComercialesEntities();
        string rutaSharePoint = System.Configuration.ConfigurationManager.AppSettings["RutaSharePoint"];
        string rutaRepositorio = System.Configuration.ConfigurationManager.AppSettings["Repositorio"];
        string user_SP = System.Configuration.ConfigurationManager.AppSettings["user_sp"];
        string pass_SP = System.Configuration.ConfigurationManager.AppSettings["pass_sp"];
        int id_user = 34;
        //86 -> Funcionario de Negocios AArce
        //94 -> gerente de Negocios CL
        //16 -> gerente de Riesgos RC
        //71 -> funcionario de Riesgos YG
        //38 -> Auxiliar de Riesgos GE


        // GET: /Seguimiento/
        public ActionResult Index()
        {
            try
            {
                var seguimiento = db.Seguimiento.Include(s => s.Operacion).Include(s => s.Usuario);
                return View(seguimiento.ToList());
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Index ", ex);
                return null;
                throw;
            }
        }


        [ChildActionOnly]
        public PartialViewResult _ListForOperacion(int OperacionID)
        {
            try
            {
                // Buscamos al usuario logueado
                Usuario usuario = db.Usuario.First(u => u.NombreUsuario == User.Identity.Name.ToUpper().Substring(7));
                usuario = db.Usuario.Find(id_user);
                ViewBag.usuario = usuario;

                var seguimientos = db.Seguimiento.Where(s => s.OperacionID == OperacionID).Include(s => s.Documento).ToList();
                return PartialView(seguimientos);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - _ListForOperacion ", ex);
                return null;
                throw;
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public JsonResult BajaOperacion(string id)
        {
            GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - BajaOperacion " + id.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
            int _operacionID = Convert.ToInt32(id);
            int _ultimoEstado = 0;
            string _fecha = DateTime.Now.ToString("yyyyMMdd", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

            try
            {
                var query = (from p in db.Operacion
                             where p.OperacionID.Equals(_operacionID)
                             select p).FirstOrDefault();
                _ultimoEstado = query.EstadoID;

                query.EstadoID = 20;
                query.Fecha_Baja = _fecha;
                query.Estado_Baja = _ultimoEstado;

                db.SaveChanges();

                return Json(new { OPERACION = id, RESULT = "OK" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception e)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Baja de Operacion ", e);
                return Json(new { OPERACION = id, RESULT = "FAILED" }, JsonRequestBehavior.AllowGet);
                throw;
            }
        }


        // GET: /Seguimiento/Details/5
        public ActionResult Details(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Seguimiento seguimiento = db.Seguimiento.Find(id);
                if (seguimiento == null)
                {
                    return HttpNotFound();
                }

                // Buscamos al usuario logueado
                Usuario usuario = db.Usuario.First(u => u.NombreUsuario == User.Identity.Name.ToUpper().Substring(7));
                usuario = db.Usuario.Find(id_user);
                ViewBag.usuario = usuario;

                ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo != "" && u.Cargo != "Instancia Aprobación"), "UsuarioID", "Nombre");
                //ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Gerente de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });

                return View(seguimiento);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Details ", ex);
                return RedirectToAction("Index", "Operacion");
                throw;
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Details(int SeguimientoID, List<int> destinatarioAdicional)
        {
            try
            {
                GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Details " + SeguimientoID.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                Seguimiento seguimiento = db.Seguimiento.Find(SeguimientoID);

                foreach (int i in destinatarioAdicional)
                {
                    Usuario usuario = db.Usuario.Find(i);
                    seguimiento.Usuario1.Add(usuario);
                }

                db.Entry(seguimiento).State = EntityState.Modified;
                db.SaveChanges();

                return RedirectToAction("Index", "Operacion");
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Details ", ex);
                return RedirectToAction("Index", "Operacion");
                throw;
            }
        }

        // GET: /Seguimiento/Create
        public ActionResult CreateFirst(int OperacionID)
        {
            try
            {
                // Buscamos la operacion
                Operacion operacion = db.Operacion.Find(OperacionID);
                ViewBag.estadoOperacion = operacion.EstadoID;

                // Creamos el nuevo seguimiento
                Seguimiento seguimiento = new Seguimiento();
                seguimiento.OperacionID = operacion.OperacionID;
                seguimiento.Fecha = DateTime.Now;

                // Buscamos al usuario logueado para asignarlo como remitente
                Usuario usuarioLogueado = db.Usuario.First(u => u.NombreUsuario == User.Identity.Name.ToUpper().Substring(7));
                usuarioLogueado = db.Usuario.Find(id_user);
                seguimiento.Usuario = usuarioLogueado;
                seguimiento.UsuarioID = usuarioLogueado.UsuarioID;

                seguimiento.Asunto = "Evaluación Negocios";
                ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Gerente de Negocios"), "UsuarioID", "Nombre");

                //return View("Create", seguimiento);

                return RedirectToAction("EvaluacionRiesgos", "Seguimiento", new { id = OperacionID });
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - CreateFirst ", ex);
                return RedirectToAction("Index", "Operacion");
                throw;
            }
        }


        // GET: /Seguimiento/Create
        public ActionResult Create(int SeguimientoID, string Caso)
        {
            try
            {
                //GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "Recupera Seguimiento: " + SeguimientoID.ToString() + " - caso: " + Caso.ToString());
                //ViewBag.OperacionID = new SelectList(db.Operacion, "OperacionID", "OperacionID", OperacionID);            
                //ViewBag.UsuarioID = new SelectList(db.Usuario, "UsuarioID", "UsuarioID", usuario.UsuarioID);

                // Buscamos la operacion
                Operacion operacion = db.Seguimiento.Find(SeguimientoID).Operacion;
                ViewBag.estadoOperacion = operacion.EstadoID;

                // Creamos el nuevo seguimiento
                Seguimiento seguimiento = new Seguimiento();
                seguimiento.OperacionID = operacion.OperacionID;
                seguimiento.Operacion = operacion;
                seguimiento.Fecha = DateTime.Now;

                // Buscamos al usuario logueado para asignarlo como remitente
                Usuario usuarioLogueado = db.Usuario.First(u => u.NombreUsuario == User.Identity.Name.ToUpper().Substring(7));
                usuarioLogueado = db.Usuario.Find(id_user);
                seguimiento.Usuario = usuarioLogueado;
                seguimiento.UsuarioID = usuarioLogueado.UsuarioID;

                // Primero evaluamos los casos especiales (donde nos salimos del flujo normal)

                if (Caso == "PendienteFiscalizacion") // Caso 1: Pendientes en Fiscalizacion
                {
                    // Ultimo seguimiento 
                    Seguimiento ultimoSeguimiento = db.Seguimiento.Find(SeguimientoID);
                    seguimiento.Asunto = ultimoSeguimiento.Asunto;
                    ViewBag.Caso = "PendienteFiscalizacion";

                    // FN responde pendientes al GR
                    if (usuarioLogueado.Cargo == "Funcionario de Negocios")
                    {
                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Gerente de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                    }

                    // GR observa respuestas de FN
                    if (usuarioLogueado.Cargo == "Gerente de Riesgos")
                    {
                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Funcionario de Negocios"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                    }
                }
                else
                {
                    try
                    {
                        // Buscamos ultimo seguimiento
                        Seguimiento ultimoSeguimiento = db.Seguimiento.Find(SeguimientoID);
                        seguimiento.Asunto = ultimoSeguimiento.Asunto;

                        switch (operacion.Estado.EstadoID)
                        {
                            case 1: // Estado = "Evaluación Negocios"
                                {
                                    // El GN revisa al "Propuesta de Negocios" enviada por el FN
                                    if (usuarioLogueado.Cargo == "Gerente de Negocios")
                                    {
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Funcionario de Negocios"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                    }

                                    // El FN envia "Propuesta de Negocios" corregida al GN
                                    if (usuarioLogueado.Cargo == "Funcionario de Negocios")
                                    {
                                        seguimiento.Asunto = "Evaluación Negocios";
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Gerente de Negocios"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                    }
                                }; break;

                            case 2: // Estado = "Conforme Negocios"
                                {

                                    // El FN envia "Propuesta de Negocios" al GR
                                    if (usuarioLogueado.Cargo == "Funcionario de Negocios")
                                    {
                                        seguimiento.Asunto = "Nueva Operación";
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Gerente de Riesgos"), "UsuarioID", "Nombre");
                                    }
                                }; break;

                            case 3: // Estado = "Nueva Operacion"
                                {

                                    // El GR revisa al "Propuesta de Negocios" enviada por el FN
                                    if (usuarioLogueado.Cargo == "Gerente de Riesgos")
                                    {
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Funcionario de Negocios"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                        ViewBag.ListaDestinatariosAdicional = new SelectList(db.Usuario.Where(u => u.Cargo == "Funcionario de Riesgos"), "UsuarioID", "Nombre");
                                    }

                                    if (usuarioLogueado.Cargo == "Subgerente de Riesgos")
                                    {
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Funcionario de Negocios"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                        ViewBag.ListaDestinatariosAdicional = new SelectList(db.Usuario.Where(u => u.Cargo == "Funcionario de Riesgos"), "UsuarioID", "Nombre");
                                    }

                                    // El FN envia "Propuesta de Negocios" corregida al GR
                                    if (usuarioLogueado.Cargo == "Funcionario de Negocios")
                                    {
                                        seguimiento.Asunto = "Nueva Operación";
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Gerente de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                    }

                                    ViewBag.enviaCorro = true;
                                }; break;

                            case 4: // Estado = "Evaluacion Riesgos"
                                {

                                    // El FR envia "consultas" para reunión In-House
                                    if (usuarioLogueado.Cargo == "Funcionario de Riesgos")
                                    {
                                        seguimiento.Asunto = "Comité In-House";
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Gerente de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                    }

                                    if (usuarioLogueado.Cargo == "Gerente de Riesgos")
                                    {
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Funcionario de Negocios"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                        ViewBag.ListaDestinatariosAdicional = new SelectList(db.Usuario.Where(u => u.Cargo == "Funcionario de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                    }

                                    ViewBag.enviaCorro = true;

                                }; break;

                            case 5: // Estado = "Comite In-house"
                                {

                                    // El GR filtra "consultas" en reunión In-House y envía a FR
                                    if (usuarioLogueado.Cargo == "Gerente de Riesgos")
                                    {
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Funcionario de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                    }

                                }; break;

                            case 6: // Estado = "Comite In-House Realizado"
                                {

                                    // El FR envia "consultas" filtradas al FN
                                    if (usuarioLogueado.Cargo == "Funcionario de Riesgos")
                                    {
                                        seguimiento.Asunto = "Gestión de Respuestas";

                                        // Buscamos al funcionario de negocios relacionado
                                        Seguimiento ultimoSeguimientoFN = db.Seguimiento.Where(s => s.OperacionID == operacion.OperacionID && s.Usuario.Cargo == "Funcionario de Negocios").OrderByDescending(s => s.SeguimientoID).First();
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Funcionario de Negocios"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimientoFN.UsuarioID });
                                    }

                                }; break;

                            case 7: // Estado = "Gestión de Respuestas"
                                {
                                    // El FN responde las "consutas" al FR
                                    if (usuarioLogueado.Cargo == "Funcionario de Negocios")
                                    {
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Funcionario de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                    }

                                    // El FR revisas las "respuestas" del FN
                                    if (usuarioLogueado.Cargo == "Funcionario de Riesgos")
                                    {
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Funcionario de Negocios"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                    }
                                    ViewBag.enviaCorro = true;
                                }; break;

                            case 8: // Estado = "Gestión de Respuestas Finalizada"
                                {

                                    // El FR envia el "Reporte de riesgos" al GR
                                    if (usuarioLogueado.Cargo == "Funcionario de Riesgos")
                                    {
                                        seguimiento.Asunto = "Revisión Reporte de Riesgos";

                                        // Buscamos al gerente de riesgos relacionado
                                        Seguimiento ultimoSeguimientoGR = db.Seguimiento.Where(s => s.OperacionID == operacion.OperacionID && s.Usuario.Cargo == "Gerente de Riesgos").OrderByDescending(s => s.SeguimientoID).First();
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Gerente de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimientoGR.UsuarioID });
                                    }

                                }; break;

                            case 9: // Estado = "Revisión Reporte de Riesgos"
                                {

                                    // El GR revisa el Reporte de Riesgos enviado por el FR
                                    if (usuarioLogueado.Cargo == "Gerente de Riesgos")
                                    {
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Funcionario de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                    }

                                    // El FR revisa las observaciones realizadas por el GR
                                    if (usuarioLogueado.Cargo == "Funcionario de Riesgos")
                                    {
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Gerente de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                    }

                                }; break;

                            case 10: // Estado = "Reporte de Riesgos Revisado"
                                {

                                    // El FR envía la "operacion" a la instancia de aprobacion (GR)
                                    if (usuarioLogueado.Cargo == "Funcionario de Riesgos")
                                    {
                                        seguimiento.Asunto = "Aprobación Pendiente";
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Gerente de Riesgos" | u.Cargo == "Instancia Aprobación"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                    }

                                }; break;

                            case 11: // Estado = "Resolucion Pendiente"
                                {

                                    // El GR resuelve la "operacion: Aprueba o Deniega" o envia comentarios/obervaciones al FR
                                    if (usuarioLogueado.Cargo == "Gerente de Riesgos")
                                    {
                                        // Buscamos al funcionario de riesgos relacionado
                                        Seguimiento ultimoSeguimientoFR = db.Seguimiento.Where(s => s.OperacionID == operacion.OperacionID && s.Usuario.Cargo == "Funcionario de Riesgos").OrderByDescending(s => s.SeguimientoID).First();
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Funcionario de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimientoFR.UsuarioID });

                                        ViewBag.ListaDestinatariosAdicional = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Gerente de Riesgos" || u.Cargo == "Instancia Aprobación"), "UsuarioID", "Nombre", new List<int> { });
                                    }

                                    // El FR revisa comentarios/obervaciones y envia al FN
                                    if (usuarioLogueado.Cargo == "Funcionario de Riesgos")
                                    {
                                        // Buscamos al gerente de riesgos relacionado
                                        Seguimiento ultimoSeguimientoGR = db.Seguimiento.Where(s => s.OperacionID == operacion.OperacionID && s.Usuario.Cargo == "Gerente de Riesgos").OrderByDescending(s => s.SeguimientoID).First();
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Funcionario de Negocios" || u.Cargo == "Gerente de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimientoGR.UsuarioID });
                                    }

                                    // El FN responde consultas al FR
                                    if (usuarioLogueado.Cargo == "Funcionario de Negocios")
                                    {
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Funcionario de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                    }


                                }; break;

                            case 12: // Estado = "Resolucion Finalizada"
                                {
                                    // El FR envia documentos a AR para activacion
                                    if (usuarioLogueado.Cargo == "Funcionario de Riesgos")
                                    {
                                        seguimiento.Asunto = "Carga Consist";
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Auxiliar de Riesgos"), "UsuarioID", "Nombre");
                                    }
                                    ViewBag.enviaCorro = true;
                                }
                                break;

                            case 13: // Estado = "Carga Consist"
                                {

                                    // El AR valida archivos de FR
                                    if (usuarioLogueado.Cargo == "Auxiliar de Riesgos")
                                    {
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Funcionario de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                        ViewBag.ListaDestinatariosAdicional = new SelectList(db.Usuario.Where(u => u.Cargo == "Gerente de Riesgos"), "UsuarioID", "Nombre");
                                    }

                                    // El FR envia documentos a AR para activacion
                                    if (usuarioLogueado.Cargo == "Funcionario de Riesgos")
                                    {
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Auxiliar de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                    }

                                }; break;

                            case 14: // Estado = "Revision Consist"
                                {

                                    // El GR envia revision de consist a AR (se activa la operacion)
                                    if (usuarioLogueado.Cargo == "Gerente de Riesgos")
                                    {
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Auxiliar de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                    }

                                    // El AR envia respuestas a GR 
                                    if (usuarioLogueado.Cargo == "Auxiliar de Riesgos")
                                    {
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Gerente de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                                    }
                                }
                                break;
                            case 15:
                                {
                                    try
                                    {
                                        //if (usuarioLogueado.Cargo == "Auxiliar de Riesgos")
                                        //{
                                        seguimiento.Asunto = "Carga SharePoint";
                                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Auxiliar de Riesgos"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });

                                        var documento = db.Documento.Include(d => d.Seguimiento).Where(u => u.Ruta.Contains(seguimiento.OperacionID.ToString())).ToList();

                                        var query = (from t1 in db.Operacion
                                                     join t2 in db.Seguimiento on t1.OperacionID.ToString() equals t2.OperacionID.ToString()
                                                     where ((t2.Asunto == "Resolución Finalizada Conjunta" || t2.Asunto == "Activado") && t2.OperacionID == seguimiento.OperacionID)
                                                     select new { t1.Region, t2.Fecha, t2.Texto, t1.Tipo }).FirstOrDefault();
                                        //select new { t1.Region, t2.Fecha };

                                        string _folderTipo = string.Empty;
                                        if (query.Tipo.Trim().Replace(" ", "").Replace("/", "_").Contains("Memo"))
                                        {
                                            _folderTipo = "Memo";
                                        }
                                        else
                                        {
                                            _folderTipo = "Reporte";
                                        }

                                        string path_fecha = DateTime.Parse(query.Fecha.ToString()).Year.ToString().Substring(2, 2) + "_" + DateTime.Parse(query.Fecha.ToString()).ToString("MM") + " " + _folderTipo;
                                        string path_region = string.Empty;
                                        string path_resolucion = string.Empty;
                                        switch (query.Region)
                                        {
                                            case "CENTRO": // Region = "CENTRO"
                                                {
                                                    path_region = "REGIÓN CENTRO";
                                                }
                                                break;
                                            case "ORIENTE": // Region = "ORIENTE"
                                                {
                                                    path_region = "REGIÓN ORIENTE";
                                                }
                                                break;
                                            case "OCCIDENTE": // Region = "OCCIDENTE"
                                                {
                                                    path_region = "REGIÓN OCCIDENTE";
                                                }
                                                break;
                                        }

                                        if (query.Texto == null)
                                        {
                                            path_resolucion = "Aprobaciones";
                                        }
                                        else
                                        {
                                            if (query.Texto.Contains("Aprobada"))
                                            {
                                                path_resolucion = "Aprobaciones";
                                            }
                                            else
                                            {
                                                path_resolucion = "Rechazados";
                                            }
                                        }

                                        //string path1 = rutaSharePoint + path_region + "\\";

                                        //var credentials = new NetworkCredential(user_SP, pass_SP, "BTBNET");
                                        //using (new NetworkConnection(path1, credentials))
                                        //{
                                        //    //string[] theFolders = System.IO.Directory.GetDirectories(path1);
                                        //    List<string> list = new List<string>();
                                        //    foreach (string s in Directory.GetDirectories(path1))
                                        //    {
                                        //        list.Add(s.Replace(path1, ""));
                                        //    }

                                        //    ViewBag.Seguimiento = documento;
                                        //    ViewBag.path = path1;
                                        //    ViewBag.Finalpath = "\\" + path_resolucion + "\\" + path_fecha + "\\";
                                        //    ViewBag.Folders = list;
                                        //}


                                        //using (new NetworkConnection(@"\\server\read", readCredentials))
                                        //using (new NetworkConnection(@"\\server2\write", writeCredentials))
                                        //{
                                        //    File.Copy(@"\\server\read\file", @"\\server2\write\file");
                                        //}


                                        //then do whatever, such as getting a list of folders:

                                        //foreach (var item in documento)
                                        //{
                                        //    string a = item.NombreArchivo
                                        //}    




                                        //}
                                    }
                                    catch (Exception ex)
                                    {
                                        GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Etapa 15 ", ex);
                                        throw;
                                    }
                                }; break;

                            case 16:
                                {
                                    seguimiento.Asunto = "Envio Ruta Circularizacion";

                                    //var _l1 = ((from t1 in db.Seguimiento
                                    //                    join t2 in db.Usuario on t1.UsuarioID equals t2.UsuarioID
                                    //                    where t1.OperacionID == seguimiento.OperacionID
                                    //                    select new { t2.UsuarioID, t2.Nombre }).Distinct().ToList());

                                    //var _l2 = (from p in db.Usuario
                                    //           where p.Cargo.Contains("Gerente de Riesgos") || p.Cargo.Contains("Instancia Aprobación Oriente")
                                    //           select new { p.UsuarioID, p.Nombre }).ToList();

                                    //var _l3 = _l1.Union(_l2);

                                    //var lista1 = new MultiSelectList(_l3, "UsuarioID", "Nombre");

                                    //ViewBag.ListaDestinatarios = lista1;

                                    //var lista1 = new MultiSelectList((from t1 in db.Seguimiento
                                    //                                  join t2 in db.Usuario on t1.UsuarioID equals t2.UsuarioID
                                    //                                  where t1.OperacionID == seguimiento.OperacionID
                                    //                                  select new { t2.UsuarioID, t2.Nombre }).Distinct().ToList(), "UsuarioID", "Nombre");


                                    //var a2 = new MultiSelectList(db.Usuario.Where(u => u.Cargo.Contains("GRUPO_LEGAL") ||
                                    //                                                                       u.Cargo.Contains("GRUPO_PPCC")), "UsuarioID", "Nombre");

                                    

                                    var query = (from t1 in db.Operacion
                                                 join t2 in db.Seguimiento on t1.OperacionID.ToString() equals t2.OperacionID.ToString()
                                                 where (t2.Asunto == "Carga SharePoint" && t2.OperacionID == seguimiento.OperacionID)
                                                 select new { t1.Region, t2.Fecha, t2.Texto }).FirstOrDefault();


                                    var query2 = (from t1 in db.Operacion
                                                  join t2 in db.Seguimiento on t1.OperacionID.ToString() equals t2.OperacionID.ToString()
                                                  where ((t2.Asunto == "Resolución Finalizada Conjunta" || t2.Asunto == "Activado") && t2.OperacionID == seguimiento.OperacionID)
                                                  select new { t1.Region, t2.Fecha, t2.Texto, t1.Tipo, t1.Cliente }).FirstOrDefault();
                                    //select new { t1.Region, t2.Fecha };
                                    //var destinatario_proceso = (from t1 in db.Seguimiento
                                    //                            join t2 in db.Usuario on t1.UsuarioID equals t2.UsuarioID
                                    //                            where t1.OperacionID == seguimiento.OperacionID
                                    //                            select new { t2.Matricula, t2.Nombre, t2.Cargo }).Distinct().ToList();




                                    string lista = string.Empty;
                                    string path_region = string.Empty;
                                    string path_resolucion = string.Empty;
                                    switch (query2.Region)
                                    {
                                        case "CENTRO": // Region = "CENTRO"
                                            {
                                                path_region = "REGIÓN CENTRO RESOLUCIONES";
                                                var _l1 = ((from t1 in db.Seguimiento
                                                            join t2 in db.Usuario on t1.UsuarioID equals t2.UsuarioID
                                                            where t1.OperacionID == seguimiento.OperacionID
                                                            select new { t2.UsuarioID, t2.Nombre }).Distinct().ToList());

                                                var _l2 = (from p in db.Usuario
                                                           where p.Cargo.Contains("Gerente de Riesgos") || p.Cargo.Contains("Instancia Aprobación Centro")
                                                           select new { p.UsuarioID, p.Nombre }).ToList();

                                                var _l3 = _l1.Union(_l2);

                                                var lista1 = new MultiSelectList(_l3, "UsuarioID", "Nombre");

                                                ViewBag.ListaDestinatarios = lista1;

                                                var destinatario_proceso = (from t1 in db.Usuario
                                                                            where t1.Cargo.Contains("GRUPO LEGAL CENTRO") || t1.Cargo.Contains("GRUPO PPCC CENTRO")
                                                                            select new { t1.Matricula, t1.Nombre, t1.Cargo }).Distinct().ToList();
                                                foreach (var item in destinatario_proceso)
                                                {
                                                    lista += "<li class='list-group-item d-flex justify-content-between align-items-center'><a href='javascript:void(0)' class='btn borrar_mail' data-id='" + item.Matricula + "@bancred.com.bo'><span class='alert-danger glyphicon glyphicon-remove'></span></a>" + @item.Nombre.ToString() + " - " + @item.Cargo.ToString() + "</li>";
                                                }
                                            }
                                            break;
                                        case "ORIENTE": // Region = "ORIENTE"
                                            {
                                                path_region = "REGIÓN ORIENTE RESOLUCIONES";
                                                var _l1 = ((from t1 in db.Seguimiento
                                                            join t2 in db.Usuario on t1.UsuarioID equals t2.UsuarioID
                                                            where t1.OperacionID == seguimiento.OperacionID
                                                            select new { t2.UsuarioID, t2.Nombre }).Distinct().ToList());

                                                var _l2 = (from p in db.Usuario
                                                           where p.Cargo.Contains("Gerente de Riesgos") || p.Cargo.Contains("Instancia Aprobación Oriente")
                                                           select new { p.UsuarioID, p.Nombre }).ToList();

                                                var _l3 = _l1.Union(_l2);

                                                var lista1 = new MultiSelectList(_l3, "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });

                                                ViewBag.ListaDestinatarios = lista1;

                                                var destinatario_proceso = (from t1 in db.Usuario
                                                                            where t1.Cargo.Contains("GRUPO LEGAL ORIENTE") || t1.Cargo.Contains("GRUPO PPCC ORIENTE")
                                                                            select new { t1.Matricula, t1.Nombre, t1.Cargo }).Distinct().ToList();
                                                foreach (var item in destinatario_proceso)
                                                {
                                                    lista += "<li class='list-group-item d-flex justify-content-between align-items-center'><a href='javascript:void(0)' class='btn borrar_mail' data-id='" + item.Matricula + "@bancred.com.bo'><span class='alert-danger glyphicon glyphicon-remove'></span></a>" + @item.Nombre.ToString() + " - " + @item.Cargo.ToString() + "</li>";
                                                }
                                            }
                                            break;
                                        case "OCCIDENTE": // Region = "OCCIDENTE"
                                            {
                                                path_region = "REGIÓN OCCIDENTE RESOLUCIONES";
                                                var _l1 = ((from t1 in db.Seguimiento
                                                            join t2 in db.Usuario on t1.UsuarioID equals t2.UsuarioID
                                                            where t1.OperacionID == seguimiento.OperacionID
                                                            select new { t2.UsuarioID, t2.Nombre }).Distinct().ToList());

                                                var _l2 = (from p in db.Usuario
                                                           where p.Cargo.Contains("Gerente de Riesgos") || p.Cargo.Contains("Instancia Aprobación Occidente")
                                                           select new { p.UsuarioID, p.Nombre }).ToList();

                                                var _l3 = _l1.Union(_l2);

                                                var lista1 = new MultiSelectList(_l3, "UsuarioID", "Nombre");

                                                ViewBag.ListaDestinatarios = lista1;

                                                var destinatario_proceso = (from t1 in db.Usuario
                                                                            where t1.Cargo.Contains("GRUPO LEGAL OCCIDENTE") || t1.Cargo.Contains("GRUPO PPCC OCCIDENTE")
                                                                            select new { t1.Matricula, t1.Nombre, t1.Cargo }).Distinct().ToList();
                                                foreach (var item in destinatario_proceso)
                                                {
                                                    lista += "<li class='list-group-item d-flex justify-content-between align-items-center'><a href='javascript:void(0)' class='btn borrar_mail' data-id='" + item.Matricula + "@bancred.com.bo'><span class='alert-danger glyphicon glyphicon-remove'></span></a>" + @item.Nombre.ToString() + " - " + @item.Cargo.ToString() + "</li>";
                                                }
                                            }
                                            break;
                                        default:
                                            {
                                                path_region = "REGIÓN OCCIDENTE RESOLUCIONES";
                                                var _l1 = ((from t1 in db.Seguimiento
                                                            join t2 in db.Usuario on t1.UsuarioID equals t2.UsuarioID
                                                            where t1.OperacionID == seguimiento.OperacionID
                                                            select new { t2.UsuarioID, t2.Nombre }).Distinct().ToList());

                                                var _l2 = (from p in db.Usuario
                                                           where p.Cargo.Contains("Gerente de Riesgos") || p.Cargo.Contains("Instancia Aprobación Occidente")
                                                           select new { p.UsuarioID, p.Nombre }).ToList();

                                                var _l3 = _l1.Union(_l2);

                                                var lista1 = new MultiSelectList(_l3, "UsuarioID", "Nombre");

                                                ViewBag.ListaDestinatarios = lista1;

                                                var destinatario_proceso = (from t1 in db.Usuario
                                                                            where t1.Cargo.Contains("GRUPO LEGAL OCCIDENTE") || t1.Cargo.Contains("GRUPO PPCC OCCIDENTE")
                                                                            select new { t1.Matricula, t1.Nombre, t1.Cargo }).Distinct().ToList();
                                                foreach (var item in destinatario_proceso)
                                                {
                                                    lista += "<li class='list-group-item d-flex justify-content-between align-items-center'><a href='javascript:void(0)' class='btn borrar_mail' data-id='" + item.Matricula + "@bancred.com.bo'><span class='alert-danger glyphicon glyphicon-remove'></span></a>" + @item.Nombre.ToString() + " - " + @item.Cargo.ToString() + "</li>";
                                                }
                                            }break;
                                    }

                                    string _folderTipo = string.Empty;
                                    if (query2.Tipo.Trim().Replace(" ", "").Replace("/", "_").Contains("Memo"))
                                    {
                                        _folderTipo = "Memo";
                                    }
                                    else
                                    {
                                        _folderTipo = "Reporte";
                                    }

                                    //string path_fecha = DateTime.Parse(query2.Fecha.ToString()).Year.ToString().Substring(2, 2) + "_" + DateTime.Parse(query2.Fecha.ToString()).ToString("MM") + " " + query2.Tipo.Trim().Replace("/", "_");
                                    string path_fecha = DateTime.Parse(query2.Fecha.ToString()).Year.ToString().Substring(2, 2) + "_" + DateTime.Parse(query2.Fecha.ToString()).ToString("MM") + " " + _folderTipo;
                                    string path1 = rutaSharePoint + path_region + "\\" + query2.Cliente.Nombre.Replace(" / ", "_") + "\\" + path_fecha;
                                    string pathaux = rutaSharePoint + path_region + "\\";
                                    ViewBag.Contenido = lista;
                                    
                                    //ViewBag.ruta = query.Texto.ToString();
                                    ViewBag.ruta = "";
                                    ViewBag.rutaPCCLEG = pathaux;

                                    //var credentials = new NetworkCredential(user_SP, pass_SP, "BTBNET");
                                    //using (new NetworkConnection(Path.GetFullPath(Path.Combine(path1, @"..\..\..\")), credentials))
                                    //{
                                    //    //if (!System.IO.Directory.Exists(path1))
                                    //    //{
                                    //    //    System.IO.Directory.CreateDirectory(path1);
                                    //    //}

                                    //    //string[] theFolders = System.IO.Directory.GetDirectories(path1);
                                    //    List<string> list = new List<string>();
                                    //    foreach (string s in Directory.GetDirectories(pathaux))
                                    //    {
                                    //        list.Add(s.Replace(pathaux, ""));
                                    //    }

                                    //    //ViewBag.Seguimiento = documento;
                                    //    ViewBag.path = path1;
                                    //    ViewBag.Finalpath = "\\" + path_resolucion + "\\" + path_fecha + "\\";
                                    //    ViewBag.Folders = list;
                                    //    ViewBag.path_fecha = path_fecha;
                                    //}


                                }; break;

                            case 17:
                                {
                                    
                                    seguimiento.Asunto = "Envio Documentacion Archivos";
                                    //if (usuarioLogueado.Cargo == "Auxiliar de Riesgos")
                                    //{
                                    var documento = db.Documento.Include(d => d.Seguimiento).Where(u => u.Ruta.Contains(seguimiento.OperacionID.ToString())).ToList();
                                    ViewBag.documentos = documento;
                                    ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "ARCHIVOS1" ||
                                                                                                           u.Cargo == "ARCHIVOS2"), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });

                                    var query = (from t1 in db.Operacion
                                                 join t2 in db.Seguimiento on t1.OperacionID.ToString() equals t2.OperacionID.ToString()
                                                 where (t2.Asunto == "Carga SharePoint" && t2.OperacionID == seguimiento.OperacionID)
                                                 select new { t1.Region, t2.Fecha, t2.Texto }).FirstOrDefault();

                                    //var credentials = new NetworkCredential(user_SP, pass_SP, "BTBNET");
                                    //using (new NetworkConnection(query.Texto, credentials))
                                    //{
                                    //    List<string> folders =
                                    //        //Provide your root Folder Path Here
                                    //    new DirectoryInfo(query.Texto)
                                    //        //Provide your FileName here
                                    //    .EnumerateFiles("*Acta*.*", SearchOption.AllDirectories)
                                    //    .Select(d => d.FullName).ToList();

                                    //    if (folders.Count > 0)
                                    //    {
                                    //        ViewBag.result = "Ya se encuentra cargado el Acta";
                                    //    }
                                    //    else
                                    //    {
                                    //        ViewBag.result = "No se encuentra cargado el Acta";
                                    //    }
                                    //}
                                    //}
                                    ViewBag.result = "";
                                }; break;

                            default:
                                {
                                }
                                break;
                        }
                    }
                    catch (Exception ex)
                    {
                        GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create GET ", ex);
                        // Si es una nueva operacion
                        seguimiento.Asunto = "Evaluación Negocios";
                        ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Gerente de Negocios"), "UsuarioID", "Nombre");
                    }

                }

                return View(seguimiento);

            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create GET ", ex);
                return RedirectToAction("Index", "Operacion");
                throw;
            }
        }


        // POST: /Seguimiento/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "SeguimientoID,OperacionID,Fecha,UsuarioID,Asunto,Texto,PlazoVencimiento,lstDocumentos,rutaSharePoint,bool_envia_correo")] Seguimiento seguimiento, HttpPostedFileBase[] archivos, List<int> destinatarios, String estado, String tipo, List<int> destinatarioAdicional, String instancia, double? cem, String Caso, String resolucion, String rdbtn3)
        {
            try
            {
                GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create " + seguimiento.SeguimientoID.ToString() + " - " + seguimiento.OperacionID.ToString() +  " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                // Buscamos la operacion
                Operacion operacion = db.Operacion.Find(seguimiento.OperacionID);

                // Buscamos al usuario logueado 
                Usuario usuarioLogueado = db.Usuario.First(u => u.NombreUsuario == User.Identity.Name.ToUpper().Substring(7));
                usuarioLogueado = db.Usuario.Find(id_user);
                seguimiento.Usuario = usuarioLogueado;

                if (ModelState.IsValid)
                {
                    // Primero evaluamos los casos especiales
                    if (Caso == "PendienteFiscalizacion") // Caso 1: Pendientes en Ficalizacion
                    {
                        // FN responde pendientes al GR
                        if (usuarioLogueado.Cargo == "Funcionario de Negocios")
                        {
                            seguimiento.PlazoVencimiento = null;
                        }

                        // GR observa respuestas de FN
                        if (usuarioLogueado.Cargo == "Gerente de Riesgos")
                        {

                            if (seguimiento.PlazoVencimiento == null)
                            {
                                seguimiento.PlazoVencimiento = null;
                            }

                        }

                    }
                    else
                    {

                        switch (operacion.Estado.EstadoID)
                        {
                            case 1: // Estado = "Evaluación Negocios"
                                {
                                    // El GN revisa al "Propuesta de Negocios" enviada por el FN                            
                                    if (usuarioLogueado.Cargo == "Gerente de Negocios" & estado != null)
                                    {
                                        seguimiento.Asunto = estado;

                                        if (estado == "Conforme Negocios")
                                        {
                                            // Actualizar "estado" de la operacion -> "(2) Conforme Negocios"
                                            Estado estadoTable = db.Estado.First(e => e.EstadoID == 2);
                                            operacion.Estado = estadoTable;
                                            db.Entry(operacion).State = EntityState.Modified;
                                            db.SaveChanges();
                                        }
                                    }

                                }; break;

                            case 2: // Estado = "Conforme Negocios"
                                {

                                    // El FN envia "Propuesta de Negocios" al GR
                                    if (usuarioLogueado.Cargo == "Funcionario de Negocios")
                                    {
                                        // Actualizar "estado" de la operacion -> "(3) Nueva operacion"
                                        Estado estadoTable = db.Estado.First(e => e.EstadoID == 3);
                                        operacion.Estado = estadoTable;
                                        db.Entry(operacion).State = EntityState.Modified;
                                        db.SaveChanges();
                                    }

                                }; break;

                            case 3: // Estado = "Nueva Operacion"
                                {

                                    // El GR revisa al "Propuesta de Negocios" enviada por el FN
                                    if (usuarioLogueado.Cargo == "Gerente de Riesgos" & estado != null)
                                    {
                                        seguimiento.Asunto = estado;

                                        if (estado == "Evaluación Riesgos")
                                        {
                                            operacion.Tipo = tipo;

                                            // Actualizar "estado" de la operacion -> "(4) Evaluación Riesgos"
                                            Estado estadoTable = db.Estado.First(e => e.EstadoID == 4);
                                            operacion.Estado = estadoTable;
                                            db.Entry(operacion).State = EntityState.Modified;
                                            db.SaveChanges();

                                            // Adicionar a destinatarios el funcionario de riesgos designado
                                            if (destinatarioAdicional != null)
                                            {
                                                foreach (int i in destinatarioAdicional)
                                                {
                                                    Usuario usuario = db.Usuario.Find(i);
                                                    seguimiento.Usuario1.Add(usuario);
                                                }

                                                var mensajehtml = @"<html>   <head>   </head>   <body >      <div class=WordSection1>         <br>         <div align=center>
            <table  Table border=0 cellspacing=25 cellpadding=0 width=956               style='width:417.35pt;mso-cellspacing:15.7pt;background: #cf6f37 ;mso-yfti-tbllook:
               184;mso-padding-alt:0in 0in 0in 0in'>               <tr>                  <td>                     <div align=center>                        <table>
                           <tr>                              <td>                                 <p  ><b><i><span style='font-size:13.5pt; color:white'>Riesgos Comerciales</span></i></b></p>
                              </td>                              <td >                                 <p   align=right style='text-align:right'>
                                    <b><i><span                                       style='font-size:13.5pt; color:white'>Notificaci&oacute;n</span></i></b>
                                    <span>                                       <o:p></o:p>                                    </span>
                                 </p>                              </td>                           </tr>                           <tr>
                              <td width=866 colspan=2 style='width:649.3pt;background:white;padding:11.25pt 11.25pt 11.25pt 11.25pt;
                                 height:333.3pt'>
                                 <table  Table border=0 cellspacing=0 cellpadding=0
                                    align=left width=837 style='width:627.6pt;mso-cellspacing:0in;mso-yfti-tbllook:
                                    1184;mso-table-lspace:7.05pt;margin-left:4.8pt;mso-table-rspace:7.05pt;
                                    margin-right:4.8pt;mso-table-anchor-vertical:paragraph;mso-table-anchor-horizontal:
                                    column;mso-table-left:left;mso-padding-alt:0in 0in 0in 0in'>
                                    <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:74.5pt'>
                                       <td width='100%' style='width:100.0%;padding:0in 0in 0in 0in;height:74.5pt'>
                                          <p   align=center style='text-align:center'>
                                             <b><i><span
                                                style='font-size:26.0pt;color:#EA6B14;'>WorkFlow Riesgos Comerciales</span></i></b>
                                             <span
                                                lang=es-419 style='font-size:12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                    <tr style='mso-yfti-irow:1;height:17.75pt'>
                                       <td width='100%' style='width:100.0%;padding:0in 0in 0in 0in;height:17.75pt'>
                                          <p   style='margin-bottom:12.0pt'>
                                             <b><span  
                                                style='font-size:12.0pt; color:#1F497D;'>Estimad@s:</span></b><span  
                                                style='font-size:12.0pt; color:#1F497D;'>&nbsp;</span>
                                             <span style='font-size:
                                                12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                    <tr style='mso-yfti-irow:2;height:120.3pt'>
                                       <td width='100%' style='width:100.0%;padding:0in 0in 0in 0in;height:120.3pt'>
                                          <p   align=center style='margin-bottom:12.0pt;text-align:
                                             center'>
                                             <span   style='font-size:12.0pt; color:#1F497D;'>Existe un nuevo seguimiento pendiente con el siguiente detalle:</span>
                                             <span   style='font-size:12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                          <p   align=center style='margin-bottom:12.0pt;text-align:
                                             center'>
                                             <span style='color:#1F497D'>
                                                <o:p>&nbsp;</o:p>
                                             </span>
                                          </p>
                                          <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Cliente: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>" + operacion.Cliente.Nombre + @"</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
										  <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Estado: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>" + operacion.Estado.Nombre + @"</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
										  <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Remitente: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>" + seguimiento.Usuario.Nombre + @"</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
										  <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Enlace: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>http://172.31.111.229/WF_COMERCIAL/</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td width='100%' >
                                          <p   align=center style='margin-bottom:12.0pt;text-align:
                                             center'>
                                             <b><span>Laboratorio de Informacion de Riesgos - LIDeR</span></b><b><span><br>
                                             </span></b>
											 
											 <span style='color:#EA6B14;'>Internos</span><span style='color:#C55A11;'>&nbsp;</span>
											 <b><span style='color:#000060; '>:</span></b>
											 <span style='font-size:12.0pt;color:#1F497D;
                                                '>&nbsp;</span><span style='color:#EA6B14; '>2374</span><b><span style='color:navy; '>&nbsp;-</span></b><span
                                                style='color:#C55A11;'>&nbsp;</span><span style='color:#EA6B14; '>2278</span><span style='color:#C55A11;'>&nbsp;</span>
                                             <b><span style='color:navy; '>-&nbsp;</span></b><span style='color:#EA6B14;'>3374</span>
                                             <span lang=es-419
                                                style='font-size:12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                 </table>
                              </td>
                           </tr>
                        </table>
                        </br>
                     </div>
                  </td>
               </tr>
            </table>
         </div>
         <p>
            <span >
               <o:p>&nbsp;</o:p>
            </span>
         </p>
      </div>
   </body>
</html>
";

                                                Sendmail(destinatarioAdicional, null, mensajehtml, null);
                                            }

                                            // Si "no" hay pendientes quitamos al FN
                                            if (seguimiento.PlazoVencimiento == null)
                                            {
                                                destinatarios = null;
                                                destinatarios = destinatarioAdicional;
                                            }

                                        }
                                    }
                                }; break;

                            case 4: // Estado = "Evaluacion Riesgos"
                                {

                                    // El FR envia "consultas" para reunión In-House
                                    if (usuarioLogueado.Cargo == "Funcionario de Riesgos")
                                    {
                                        // Actualizar "estado" de la operacion -> "(5) Comité In-House"
                                        Estado estadoTable = db.Estado.First(e => e.EstadoID == 5);
                                        operacion.Estado = estadoTable;
                                        db.Entry(operacion).State = EntityState.Modified;
                                        db.SaveChanges();
                                    }

                                }; break;

                            case 5: // Estado = "Comite In-House"
                                {

                                    // El GR filtra "consultas" en reunión In-House y envía a FR
                                    if (usuarioLogueado.Cargo == "Gerente de Riesgos")
                                    {
                                        // Actualizar "estado" de la operacion -> "(6) Comité In-House Realizado"
                                        Estado estadoTable = db.Estado.First(e => e.EstadoID == 6);
                                        operacion.Estado = estadoTable;
                                        db.Entry(operacion).State = EntityState.Modified;
                                        db.SaveChanges();

                                        // TODO: debemos hacer esto para igualar s.auntos con e.nombre
                                        seguimiento.Asunto = estadoTable.Nombre;
                                    }

                                }; break;

                            case 6: // Estado = "Comite In-House realizado"
                                {

                                    // El FR envia "consultas" filtradas al FN 
                                    if (usuarioLogueado.Cargo == "Funcionario de Riesgos")
                                    {
                                        // Actualizar "estado" de la operacion -> "(7) Gestión de respuestas"
                                        Estado estadoTable = db.Estado.First(e => e.EstadoID == 7);
                                        operacion.Estado = estadoTable;
                                        db.Entry(operacion).State = EntityState.Modified;
                                        db.SaveChanges();
                                    }

                                }; break;

                            case 7: // Estado = "Gestión de respuestas"
                                {

                                    // El FR revisa las "respuestas" del FN
                                    if (usuarioLogueado.Cargo == "Funcionario de Riesgos" & estado != null)
                                    {
                                        seguimiento.Asunto = estado;

                                        if (estado == "Gestión de Respuestas Finalizada")
                                        {
                                            // Actualizar "estado" de la operacion -> "(8) Gestión de Respuestas Finalizada"
                                            Estado estadoTable = db.Estado.First(e => e.EstadoID == 8);
                                            operacion.Estado = estadoTable;
                                            db.Entry(operacion).State = EntityState.Modified;
                                            db.SaveChanges();

                                            // Agregamos al FR como destinatario para que el continue con el flujo
                                            Usuario usuario = db.Usuario.Find(usuarioLogueado.UsuarioID);
                                            seguimiento.Usuario1.Add(usuario);

                                            // Borramos a los destinatarios
                                            destinatarios = null;

                                        }
                                    }

                                }; break;

                            case 8: // Estado = "Gestión de Respuestas Finalizada"
                                {

                                    // El FR envia el "Reporte de riesgos" al GR
                                    if (usuarioLogueado.Cargo == "Funcionario de Riesgos")
                                    {
                                        // Actualizar "estado" de la operacion -> "(9) Revisión Reporte de Riesgos"
                                        Estado estadoTable = db.Estado.First(e => e.EstadoID == 9);
                                        operacion.Estado = estadoTable;
                                        db.Entry(operacion).State = EntityState.Modified;
                                        db.SaveChanges();
                                    }

                                }; break;

                            case 9: // Estado = "Revisión Reporte de Riesgos"
                                {

                                    // El GR revisa las "observaciones" corregidas del FR
                                    if (usuarioLogueado.Cargo == "Gerente de Riesgos")
                                    {
                                        seguimiento.Asunto = estado;

                                        if (estado == "Reporte de Riesgos Revisado")
                                        {
                                            // Actualizar "estado" de la operacion -> "(10) Reporte de Riesgos Revisado"
                                            Estado estadoTable = db.Estado.First(e => e.EstadoID == 10);
                                            operacion.Estado = estadoTable;
                                            db.Entry(operacion).State = EntityState.Modified;
                                            db.SaveChanges();
                                        }
                                    }

                                }; break;

                            case 10: // Estado = "Reporte de Riesgos Revisado"
                                {

                                    // El FR envía la "operacion" a la instancia de aprobacion correspondiente (GR)
                                    if (usuarioLogueado.Cargo == "Funcionario de Riesgos")
                                    {
                                        // Asunto según la instancia de aprobacion elegida 
                                        seguimiento.Asunto = estado;

                                        // Actualizar "estado" de la operacion -> "(11) Resolución Pendiente"
                                        Estado estadoTable = db.Estado.First(e => e.EstadoID == 11);
                                        operacion.Estado = estadoTable;
                                        db.Entry(operacion).State = EntityState.Modified;
                                        db.SaveChanges();
                                    }

                                }; break;

                            case 11: // Estado = "Resolucion Pendiente"
                                {

                                    // El GR resuelve la "operacion: Aprueba o Deniega" o envia comentarios/obervaciones al FR
                                    if (usuarioLogueado.Cargo == "Gerente de Riesgos" & instancia != null & estado != null)
                                    {
                                        seguimiento.Asunto = estado + " " + instancia;

                                        // Adicionar a destinatarios los asistentes del comite
                                        if (destinatarioAdicional != null)
                                        {
                                            foreach (int i in destinatarioAdicional)
                                            {
                                                Usuario usuario = db.Usuario.Find(i);
                                                seguimiento.Usuario1.Add(usuario);
                                            }
                                        }

                                        if (estado == "Resolución Finalizada")
                                        {
                                            if (cem.HasValue)
                                            {
                                                operacion.CEM = cem.Value;
                                            }

                                            //if (resolucion == "Denegada")
                                            //{
                                            //    // Actualizar "estado" de la operacion -> "(12) Resolución Finalizada"
                                            //    Estado estadoTable = db.Estado.First(e => e.EstadoID == 15);
                                            //    int fun_aux = Convert.ToInt32(rdbtn3);
                                            //    destinatarios.Add(fun_aux);
                                            //    operacion.Estado = estadoTable;
                                            //    db.Entry(operacion).State = EntityState.Modified;
                                            //    db.SaveChanges();
                                            //}
                                            //else {
                                                // Actualizar "estado" de la operacion -> "(12) Resolución Finalizada"
                                                Estado estadoTable = db.Estado.First(e => e.EstadoID == 12);
                                                operacion.Estado = estadoTable;
                                                db.Entry(operacion).State = EntityState.Modified;
                                                db.SaveChanges();
                                            //}   
                                        }
                                    }

                                }; break;

                            case 12: // Estado = "Resolucion Finalizada"
                                {

                                    // El FR envía documentos a AR para activacion
                                    if (usuarioLogueado.Cargo == "Funcionario de Riesgos")
                                    {

                                        // Actualizar "estado" de la operacion -> "(13) Carga Consist"
                                        Estado estadoTable = db.Estado.First(e => e.EstadoID == 13);
                                        operacion.Estado = estadoTable;
                                        db.Entry(operacion).State = EntityState.Modified;
                                        db.SaveChanges();
                                    }

                                }; break;

                            case 13: // Estado = "Carga Consist"
                                {

                                    // El AR envía operacion a GR para revision de consist
                                    if (usuarioLogueado.Cargo == "Auxiliar de Riesgos" & estado != null)
                                    {
                                        
                                        seguimiento.Asunto = estado;

                                        if (estado == "Carga Consist Finalizada")
                                        {
                                            // Actualizar "estado" de la operacion -> "(14) Revisión Consist"
                                            Estado estadoTable = db.Estado.First(e => e.EstadoID == 14);
                                            operacion.Estado = estadoTable;
                                            db.Entry(operacion).State = EntityState.Modified;
                                            db.SaveChanges();

                                            // TODO: debemos hacer esto para igualar s.auntos con e.nombre
                                            seguimiento.Asunto = estadoTable.Nombre;
                                            // Enviamos el mensaje al GR correspondiente
                                            destinatarios = null;

                                            foreach (int i in destinatarioAdicional)
                                            {
                                                Usuario usuario = db.Usuario.Find(i);
                                                seguimiento.Usuario1.Add(usuario);
                                            }
                                        }

                                        //if (estado == "Carga Consist etapa circularizacion")
                                        //{
                                        //    //Actualizar "estado" de la operacion -> "(16) NO DEFINIDO"
                                        //    Estado estadoTable = db.Estado.First(e => e.EstadoID == 15);
                                        //    operacion.Estado = estadoTable;

                                        //    //destinatarios.Add(usuarioLogueado.UsuarioID);
                                        //    db.Entry(operacion).State = EntityState.Modified;
                                        //    db.SaveChanges();
                                        //    seguimiento.Texto = seguimiento.rutaSharePoint;
                                        //    destinatarios = null;
                                        //    int user_id = usuarioLogueado.UsuarioID;
                                        //    destinatarios = new List<int>(1) { user_id };
                                        //}
                                    }
                                }; break;


                            case 14: // Estado = "Revision Consist"
                                {
                                    // El GR activa la operacion en consist
                                    if (usuarioLogueado.Cargo == "Gerente de Riesgos" & estado != null)
                                    {
                                        seguimiento.Asunto = estado;
                                        if (estado == "Activado")
                                        {
                                            // Actualizar "estado" de la operacion -> "(15) Activado"
                                            Estado estadoTable = db.Estado.First(e => e.EstadoID == 15);
                                            operacion.Estado = estadoTable;
                                            db.Entry(operacion).State = EntityState.Modified;
                                            db.SaveChanges();
                                            // TODO: debemos hacer esto para igualar s.auntos con e.nombre
                                            seguimiento.Asunto = estadoTable.Nombre;
                                        }
                                    }
                                }; break;
                            case 15:
                                {
                                    //var credentials = new NetworkCredential(user_SP, pass_SP, "BTBNET");
                                    //using (new NetworkConnection(Path.GetFullPath(Path.Combine(seguimiento.rutaSharePoint, @"..\..\")), credentials))
                                    //{
                                    //    if (!System.IO.Directory.Exists(seguimiento.rutaSharePoint))
                                    //    {
                                    //        System.IO.Directory.CreateDirectory(seguimiento.rutaSharePoint);
                                    //    }

                                    //    var resp = seguimiento.lstDocumentos;
                                    //    //seguimiento.Asunto = "";
                                    //    //seguimiento.Asunto = estado;
                                    //    string[] Vec = new string[] { "" };
                                    //    string nameFile = string.Empty;
                                    //    Vec = resp.Split(',');
                                        
                                    //    for (int i = 0; i < Vec.LongLength; i++)
                                    //    {
                                    //        string RutaInicio = Vec[i];
                                    //        //string fileName = Vec[i + 1];
                                    //        //seguimiento.Asunto += Vec[i + 1] + "-";
                                    //        string RutaDestino = seguimiento.rutaSharePoint; // <--Colocar ruta
                                    //        nameFile = Path.GetFileName(RutaInicio);
                                    //        string Inicio = System.IO.Path.Combine(RutaInicio);
                                    //        string Destino = System.IO.Path.Combine(RutaDestino, nameFile);

                                    //        if (System.IO.File.Exists(Inicio) && !System.IO.File.Exists(Destino))
                                    //        {
                                    //            System.IO.File.Copy(Inicio, Destino, true);
                                    //        }
                                    //    }

                                    //    if (archivos[0] != null)
                                    //    {
                                    //        string ruta = seguimiento.rutaSharePoint;

                                    //        foreach (var f in archivos)
                                    //        {
                                    //            string archivo = (ruta + "\\" + f.FileName).ToLower();
                                    //            f.SaveAs(Path.Combine(@ruta, Path.GetFileName(archivo)));
                                    //        }
                                    //    }

                                    //    //Actualizar "estado" de la operacion -> "(16) NO DEFINIDO"
                                    //    Estado estadoTable = db.Estado.First(e => e.EstadoID == 16);
                                    //    operacion.Estado = estadoTable;

                                    //    //destinatarios.Add(usuarioLogueado.UsuarioID);
                                    //    db.Entry(operacion).State = EntityState.Modified;
                                    //    db.SaveChanges();
                                    //    seguimiento.Texto = seguimiento.rutaSharePoint;
                                    //    destinatarios = null;
                                    //}

                                    if (archivos[0] != null)
                                    {
                                        string ruta = seguimiento.rutaSharePoint;

                                        foreach (var f in archivos)
                                        {
                                            string archivo = (ruta + "\\" + f.FileName).ToLower();
                                            f.SaveAs(Path.Combine(@ruta, Path.GetFileName(archivo)));
                                        }
                                    }

                                    //Actualizar "estado" de la operacion -> "(16) NO DEFINIDO"
                                    Estado estadoTable = db.Estado.First(e => e.EstadoID == 16);
                                    operacion.Estado = estadoTable;

                                    //destinatarios.Add(usuarioLogueado.UsuarioID);
                                    db.Entry(operacion).State = EntityState.Modified;
                                    db.SaveChanges();
                                    seguimiento.Texto = seguimiento.rutaSharePoint;
                                    destinatarios = null;

                                }; break;

                            case 16:
                                {
                                    var query = (from t1 in db.Seguimiento
                                                 where (t1.Asunto == "Carga SharePoint" && t1.OperacionID == seguimiento.OperacionID)
                                                 select new { t1.Texto }).FirstOrDefault();
                                    List<string> lstdocs = new List<string>();

                                    var mensajehtml = @"<html>   <head>   </head>   <body >      <div class=WordSection1>         <br>         <div align=center>
            <table  Table border=0 cellspacing=25 cellpadding=0 width=956               style='width:417.35pt;mso-cellspacing:15.7pt;background: #cf6f37 ;mso-yfti-tbllook:
               184;mso-padding-alt:0in 0in 0in 0in'>               <tr>                  <td>                     <div align=center>                        <table>
                           <tr>                              <td>                                 <p  ><b><i><span style='font-size:13.5pt; color:white'>Riesgos Comerciales</span></i></b></p>
                              </td>                              <td >                                 <p   align=right style='text-align:right'>
                                    <b><i><span                                       style='font-size:13.5pt; color:white'>Notificaci&oacute;n</span></i></b>
                                    <span>                                       <o:p></o:p>                                    </span>
                                 </p>                              </td>                           </tr>                           <tr>
                              <td width=866 colspan=2 style='width:649.3pt;background:white;padding:11.25pt 11.25pt 11.25pt 11.25pt;
                                 height:333.3pt'>
                                 <table  Table border=0 cellspacing=0 cellpadding=0
                                    align=left width=837 style='width:627.6pt;mso-cellspacing:0in;mso-yfti-tbllook:
                                    1184;mso-table-lspace:7.05pt;margin-left:4.8pt;mso-table-rspace:7.05pt;
                                    margin-right:4.8pt;mso-table-anchor-vertical:paragraph;mso-table-anchor-horizontal:
                                    column;mso-table-left:left;mso-padding-alt:0in 0in 0in 0in'>
                                    <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:74.5pt'>
                                       <td width='100%' style='width:100.0%;padding:0in 0in 0in 0in;height:74.5pt'>
                                          <p   align=center style='text-align:center'>
                                             <b><i><span
                                                style='font-size:26.0pt;color:#EA6B14;'>WorkFlow Riesgos Comerciales</span></i></b>
                                             <span
                                                lang=es-419 style='font-size:12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                    <tr style='mso-yfti-irow:1;height:17.75pt'>
                                       <td width='100%' style='width:100.0%;padding:0in 0in 0in 0in;height:17.75pt'>
                                          <p   style='margin-bottom:12.0pt'>
                                             <b><span  
                                                style='font-size:12.0pt; color:#1F497D;'>Estimad@s:</span></b><span  
                                                style='font-size:12.0pt; color:#1F497D;'>&nbsp;</span>
                                             <span style='font-size:
                                                12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                    <tr style='mso-yfti-irow:2;height:120.3pt'>
                                       <td width='100%' style='width:100.0%;padding:0in 0in 0in 0in;height:120.3pt'>
                                          <p   align=center style='margin-bottom:12.0pt;text-align:
                                             center'>
                                             <span   style='font-size:12.0pt; color:#1F497D;'>Existe un nuevo seguimiento pendiente con el siguiente detalle:</span>
                                             <span   style='font-size:12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                          <p   align=center style='margin-bottom:12.0pt;text-align:
                                             center'>
                                             <span style='color:#1F497D'>
                                                <o:p>&nbsp;</o:p>
                                             </span>
                                          </p>
                                          <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Cliente: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>" + operacion.Cliente.Nombre + @"</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
										  <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Estado: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>" + operacion.Estado.Nombre + @"</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
										  <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Remitente: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>" + seguimiento.Usuario.Nombre + @"</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
										  <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Enlace: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>http://172.31.111.229/WF_COMERCIAL/</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td width='100%' >
                                          <p   align=center style='margin-bottom:12.0pt;text-align:
                                             center'>
                                             <b><span>Laboratorio de Informacion de Riesgos - LIDeR</span></b><b><span><br>
                                             </span></b>
											 
											 <span style='color:#EA6B14;'>Internos</span><span style='color:#C55A11;'>&nbsp;</span>
											 <b><span style='color:#000060; '>:</span></b>
											 <span style='font-size:12.0pt;color:#1F497D;
                                                '>&nbsp;</span><span style='color:#EA6B14; '>2374</span><b><span style='color:navy; '>&nbsp;-</span></b><span
                                                style='color:#C55A11;'>&nbsp;</span><span style='color:#EA6B14; '>2278</span><span style='color:#C55A11;'>&nbsp;</span>
                                             <b><span style='color:navy; '>-&nbsp;</span></b><span style='color:#EA6B14;'>3374</span>
                                             <span lang=es-419
                                                style='font-size:12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                 </table>
                              </td>
                           </tr>
                        </table>
                        </br>
                     </div>
                  </td>
               </tr>
            </table>
         </div>
         <p>
            <span >
               <o:p>&nbsp;</o:p>
            </span>
         </p>
      </div>
   </body>
</html>
";

                                    Sendmail(destinatarios, null, mensajehtml, null);
                                    destinatarios = null;

                                    var resp = seguimiento.rutaSharePoint;
                                    List<string> lstmail = new List<string>();
                                    if (resp != null)
                                    {
                                        string[] Vec = new string[] { "" };
                                        Vec = resp.Split(';');
                                        
                                        for (int i = 0; i < Vec.LongLength; i++)
                                        {
                                            string mail = Vec[i];

                                            if (mail != "")
                                            {
                                                lstmail.Add(mail);
                                                //lstmail.Add("FCondoriR@bancred.com.bo");
                                            }
                                        }
                                    }

                                    

                                    if (archivos[0] != null)
                                    {
                                        var query_ruta = (from t1 in db.Operacion
                                                          join t2 in db.Seguimiento on t1.OperacionID.ToString() equals t2.OperacionID.ToString()
                                                          where (t2.Asunto == "Carga SharePoint" && t2.OperacionID == seguimiento.OperacionID)
                                                          select new { t1.Region, t2.Fecha, t2.Texto }).FirstOrDefault();

                                        foreach (var f in archivos)
                                        {
                                            string archivo = (query_ruta.Texto + "\\" + f.FileName).ToLower();
                                            f.SaveAs(Path.Combine(query_ruta.Texto, Path.GetFileName(archivo)));
                                            lstdocs.Add(Path.Combine(query_ruta.Texto, Path.GetFileName(archivo)));
                                        }
                                    }

                                    var query2 = (from t1 in db.Operacion
                                                  join t2 in db.Seguimiento on t1.OperacionID.ToString() equals t2.OperacionID.ToString()
                                                  where ((t2.Asunto == "Resolución Finalizada Conjunta" || t2.Asunto == "Activado") && t2.OperacionID == seguimiento.OperacionID)
                                                  select new { t1.Region, t2.Fecha, t2.Texto, t1.Tipo, t1.Cliente }).FirstOrDefault();


                                    string path1 = string.Empty;

                                    if (seguimiento.lstDocumentos != null)
                                    {
                                        path1 = seguimiento.lstDocumentos.ToString();
                                    }
                                    else 
                                    {
                                        string path_region = string.Empty;
                                        string path_resolucion = string.Empty;
                                        switch (query2.Region)
                                        {
                                            case "CENTRO": // Region = "CENTRO"
                                                {
                                                    path_region = "REGIÓN CENTRO RESOLUCIONES";
                                                }
                                                break;
                                            case "ORIENTE": // Region = "ORIENTE"
                                                {
                                                    path_region = "REGIÓN ORIENTE RESOLUCIONES";
                                                }
                                                break;
                                            case "OCCIDENTE": // Region = "OCCIDENTE"
                                                {
                                                    path_region = "REGIÓN OCCIDENTE RESOLUCIONES";
                                                }
                                                break;
                                        }

                                        string _folderTipo = string.Empty;
                                        if (query2.Tipo.Trim().Replace(" ", "").Replace("/", "_").Contains("Memo"))
                                        {
                                            _folderTipo = "Memo";
                                        }
                                        else
                                        {
                                            _folderTipo = "Reporte";
                                        }

                                        //string path_fecha = DateTime.Parse(query2.Fecha.ToString()).Year.ToString().Substring(2, 2) + "_" + DateTime.Parse(query2.Fecha.ToString()).ToString("MM") + " " + query2.Tipo.Trim().Replace("/", "_");
                                        string path_fecha = DateTime.Parse(query2.Fecha.ToString()).Year.ToString().Substring(2, 2) + "_" + DateTime.Parse(query2.Fecha.ToString()).ToString("MM") + " " + _folderTipo;
                                        path1 = rutaSharePoint + path_region + "\\" + query2.Cliente.Nombre.Replace(" / ", "_") + "\\" + path_fecha;  
                                    }

                                    //var credentials = new NetworkCredential(user_SP, pass_SP, "BTBNET");
                                    //using (new NetworkConnection(Path.GetFullPath(Path.Combine(path1, @"..\..\..\")), credentials))
                                    //{
                                    //    if (!System.IO.Directory.Exists(path1))
                                    //    {
                                    //        System.IO.Directory.CreateDirectory(path1);
                                    //    }
                                    //}

                                    string mensajehtml2 = string.Empty;
                                    mensajehtml2 = @"<html>   <head>   </head>   <body >      <div class=WordSection1>         <br>         <div align=center>
            <table  Table border=0 cellspacing=25 cellpadding=0 width=956               style='width:417.35pt;mso-cellspacing:15.7pt;background: #cf6f37 ;mso-yfti-tbllook:
               184;mso-padding-alt:0in 0in 0in 0in'>               <tr>                  <td>                     <div align=center>                        <table>
                           <tr>                              <td>                                 <p  ><b><i><span style='font-size:13.5pt; color:white'>Riesgos Comerciales</span></i></b></p>
                              </td>                              <td >                                 <p   align=right style='text-align:right'>
                                    <b><i><span                                       style='font-size:13.5pt; color:white'>Notificaci&oacute;n</span></i></b>
                                    <span>                                       <o:p></o:p>                                    </span>
                                 </p>                              </td>                           </tr>                           <tr>
                              <td width=866 colspan=2 style='width:649.3pt;background:white;padding:11.25pt 11.25pt 11.25pt 11.25pt;
                                 height:333.3pt'>
                                 <table  Table border=0 cellspacing=0 cellpadding=0
                                    align=left width=837 style='width:627.6pt;mso-cellspacing:0in;mso-yfti-tbllook:
                                    1184;mso-table-lspace:7.05pt;margin-left:4.8pt;mso-table-rspace:7.05pt;
                                    margin-right:4.8pt;mso-table-anchor-vertical:paragraph;mso-table-anchor-horizontal:
                                    column;mso-table-left:left;mso-padding-alt:0in 0in 0in 0in'>
                                    <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:74.5pt'>
                                       <td width='100%' style='width:100.0%;padding:0in 0in 0in 0in;height:74.5pt'>
                                          <p   align=center style='text-align:center'>
                                             <b><i><span
                                                style='font-size:26.0pt;color:#EA6B14;'>WorkFlow Riesgos Comerciales</span></i></b>
                                             <span
                                                lang=es-419 style='font-size:12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                    <tr style='mso-yfti-irow:1;height:17.75pt'>
                                       <td width='100%' style='width:100.0%;padding:0in 0in 0in 0in;height:17.75pt'>
                                          <p   style='margin-bottom:12.0pt'>
                                             <b><span  
                                                style='font-size:12.0pt; color:#1F497D;'>Estimad@s:</span></b><span  
                                                style='font-size:12.0pt; color:#1F497D;'>&nbsp;</span>
                                             <span style='font-size:
                                                12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                    <tr style='mso-yfti-irow:2;height:120.3pt'>
                                       <td width='100%' style='width:100.0%;padding:0in 0in 0in 0in;height:120.3pt'>
                                          <p   align=center style='margin-bottom:12.0pt;text-align:
                                             center'>
                                             <span   style='font-size:12.0pt; color:#1F497D;'>Existe un nuevo seguimiento pendiente con el siguiente detalle:</span>
                                             <span   style='font-size:12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                          <p   align=center style='margin-bottom:12.0pt;text-align:
                                             center'>
                                             <span style='color:#1F497D'>
                                                <o:p>&nbsp;</o:p>
                                             </span>
                                          </p>
                                          <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Cliente: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>" + operacion.Cliente.Nombre + @"</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
										  <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Estado: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>" + operacion.Estado.Nombre + @"</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
										  <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Remitente: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>" + seguimiento.Usuario.Nombre + @"</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
										  <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Enlace: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>http://172.31.111.229/WF_COMERCIAL/</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td width='100%' >
                                          <p   align=center style='margin-bottom:12.0pt;text-align:
                                             center'>
                                             <b><span>Laboratorio de Informacion de Riesgos - LIDeR</span></b><b><span><br>
                                             </span></b>
											 
											 <span style='color:#EA6B14;'>Internos</span><span style='color:#C55A11;'>&nbsp;</span>
											 <b><span style='color:#000060; '>:</span></b>
											 <span style='font-size:12.0pt;color:#1F497D;
                                                '>&nbsp;</span><span style='color:#EA6B14; '>2374</span><b><span style='color:navy; '>&nbsp;-</span></b><span
                                                style='color:#C55A11;'>&nbsp;</span><span style='color:#EA6B14; '>2278</span><span style='color:#C55A11;'>&nbsp;</span>
                                             <b><span style='color:navy; '>-&nbsp;</span></b><span style='color:#EA6B14;'>3374</span>
                                             <span lang=es-419
                                                style='font-size:12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                 </table>
                              </td>
                           </tr>
                        </table>
                        </br>
                     </div>
                  </td>
               </tr>
            </table>
         </div>
         <p>
            <span >
               <o:p>&nbsp;</o:p>
            </span>
         </p>
      </div>
   </body>
</html>
";

                                    Sendmail(null, lstmail, mensajehtml2, lstdocs);
                                    destinatarios = null;
                                    //Sendmail(null, lstmail, mensajehtml);

                                    //Actualizar "estado" de la operacion -> "(16) NO DEFINIDO"
                                    Estado estadoTable = db.Estado.First(e => e.EstadoID == 17);
                                    operacion.Estado = estadoTable;

                                    //                                destinatarios.Add(usuarioLogueado.UsuarioID);
                                    db.Entry(operacion).State = EntityState.Modified;
                                    db.SaveChanges();
                                }; break;

                            case 17:
                                {

                                    var resp = seguimiento.rutaSharePoint + "GEsteban@bcp.com.bo";
                                    var docs = seguimiento.lstDocumentos;
                                    List<string> lstdocs = new List<string>();

                                    string[] Vec = new string[] { "" };
                                    Vec = resp.Split(';');
                                    List<string> lstmail = new List<string>();
                                    for (int i = 0; i < Vec.LongLength; i++)
                                    {
                                        string mail = Vec[i];

                                        if (mail != "")
                                        {
                                            lstmail.Add(mail);
                                        }
                                    }

                                    string[] Vecdocs = new string[] { "" };

                                    if (docs != null)
                                    {
                                        Vecdocs = docs.Split(',');
                                        for (int i = 0; i < Vecdocs.LongLength; i++)
                                        {
                                            string docAdjunto = Vecdocs[i];
                                            if (docAdjunto != "")
                                            {
                                                lstdocs.Add(docAdjunto);
                                            }
                                        }
                                    }

                                    

                                    if (archivos[0] != null)
                                    {
                                        var query = (from t1 in db.Operacion
                                                     join t2 in db.Seguimiento on t1.OperacionID.ToString() equals t2.OperacionID.ToString()
                                                     where (t2.Asunto == "Carga SharePoint" && t2.OperacionID == seguimiento.OperacionID)
                                                     select new { t1.Region, t2.Fecha, t2.Texto }).FirstOrDefault();

                                        foreach (var f in archivos)
                                        {
                                            string archivo = (query.Texto + "\\" + f.FileName).ToLower();
                                            f.SaveAs(Path.Combine(@query.Texto, Path.GetFileName(archivo)));
                                        }
                                    }

                                    var mensajehtml = @"<html>   <head>   </head>   <body >      <div class=WordSection1>         <br>         <div align=center>
            <table  Table border=0 cellspacing=25 cellpadding=0 width=956               style='width:417.35pt;mso-cellspacing:15.7pt;background: #cf6f37 ;mso-yfti-tbllook:
               184;mso-padding-alt:0in 0in 0in 0in'>               <tr>                  <td>                     <div align=center>                        <table>
                           <tr>                              <td>                                 <p  ><b><i><span style='font-size:13.5pt; color:white'>Riesgos Comerciales</span></i></b></p>
                              </td>                              <td >                                 <p   align=right style='text-align:right'>
                                    <b><i><span                                       style='font-size:13.5pt; color:white'>Notificaci&oacute;n</span></i></b>
                                    <span>                                       <o:p></o:p>                                    </span>
                                 </p>                              </td>                           </tr>                           <tr>
                              <td width=866 colspan=2 style='width:649.3pt;background:white;padding:11.25pt 11.25pt 11.25pt 11.25pt;
                                 height:333.3pt'>
                                 <table  Table border=0 cellspacing=0 cellpadding=0
                                    align=left width=837 style='width:627.6pt;mso-cellspacing:0in;mso-yfti-tbllook:
                                    1184;mso-table-lspace:7.05pt;margin-left:4.8pt;mso-table-rspace:7.05pt;
                                    margin-right:4.8pt;mso-table-anchor-vertical:paragraph;mso-table-anchor-horizontal:
                                    column;mso-table-left:left;mso-padding-alt:0in 0in 0in 0in'>
                                    <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:74.5pt'>
                                       <td width='100%' style='width:100.0%;padding:0in 0in 0in 0in;height:74.5pt'>
                                          <p   align=center style='text-align:center'>
                                             <b><i><span
                                                style='font-size:26.0pt;color:#EA6B14;'>WorkFlow Riesgos Comerciales</span></i></b>
                                             <span
                                                lang=es-419 style='font-size:12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                    <tr style='mso-yfti-irow:1;height:17.75pt'>
                                       <td width='100%' style='width:100.0%;padding:0in 0in 0in 0in;height:17.75pt'>
                                          <p   style='margin-bottom:12.0pt'>
                                             <b><span  
                                                style='font-size:12.0pt; color:#1F497D;'>Estimad@s:</span></b><span  
                                                style='font-size:12.0pt; color:#1F497D;'>&nbsp;</span>
                                             <span style='font-size:
                                                12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                    <tr style='mso-yfti-irow:2;height:120.3pt'>
                                       <td width='100%' style='width:100.0%;padding:0in 0in 0in 0in;height:120.3pt'>
                                          <p   align=center style='margin-bottom:12.0pt;text-align:
                                             center'>
                                             <span   style='font-size:12.0pt; color:#1F497D;'>Existe un nuevo seguimiento pendiente con el siguiente detalle:</span>
                                             <span   style='font-size:12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                          <p   align=center style='margin-bottom:12.0pt;text-align:
                                             center'>
                                             <span style='color:#1F497D'>
                                                <o:p>&nbsp;</o:p>
                                             </span>
                                          </p>
                                          <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Cliente: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>" + operacion.Cliente.Nombre + @"</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
										  <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Estado: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>" + operacion.Estado.Nombre + @"</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
										  <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Remitente: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>" + seguimiento.Usuario.Nombre + @"</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
										  <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Enlace: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>http://172.31.111.229/WF_COMERCIAL/</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td width='100%' >
                                          <p   align=center style='margin-bottom:12.0pt;text-align:
                                             center'>
                                             <b><span>Laboratorio de Informacion de Riesgos - LIDeR</span></b><b><span><br>
                                             </span></b>
											 
											 <span style='color:#EA6B14;'>Internos</span><span style='color:#C55A11;'>&nbsp;</span>
											 <b><span style='color:#000060; '>:</span></b>
											 <span style='font-size:12.0pt;color:#1F497D;
                                                '>&nbsp;</span><span style='color:#EA6B14; '>2374</span><b><span style='color:navy; '>&nbsp;-</span></b><span
                                                style='color:#C55A11;'>&nbsp;</span><span style='color:#EA6B14; '>2278</span><span style='color:#C55A11;'>&nbsp;</span>
                                             <b><span style='color:navy; '>-&nbsp;</span></b><span style='color:#EA6B14;'>3374</span>
                                             <span lang=es-419
                                                style='font-size:12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                 </table>
                              </td>
                           </tr>
                        </table>
                        </br>
                     </div>
                  </td>
               </tr>
            </table>
         </div>
         <p>
            <span >
               <o:p>&nbsp;</o:p>
            </span>
         </p>
      </div>
   </body>
</html>
";

                                    Sendmail(destinatarios, lstmail, mensajehtml, lstdocs);
                                    destinatarios = null;
                                    //Sendmail(null, lstmail, mensajehtml);

                                    //Actualizar "estado" de la operacion -> "(16) NO DEFINIDO"
                                    Estado estadoTable = db.Estado.First(e => e.EstadoID == 18);
                                    operacion.Estado = estadoTable;

                                    //                                destinatarios.Add(usuarioLogueado.UsuarioID);
                                    db.Entry(operacion).State = EntityState.Modified;
                                    db.SaveChanges();
                                }; break;
                        }
                    }


                    // Guardamos los Destinatarios
                    if (destinatarios != null)
                    {
                        foreach (int i in destinatarios)
                        {
                            Usuario usuario = db.Usuario.Find(i);
                            seguimiento.Usuario1.Add(usuario);
                        }
                    }

                    // Guardamos el Seguimiento 
                    db.Seguimiento.Add(seguimiento);
                    db.SaveChanges();

                    // Guardamos documentos adjuntos
                    if (archivos[0] != null)
                    {

                        //string ruta = "d:\\\\WFComercialArchivos\\" + seguimiento.OperacionID;
                        string ruta = "\\\\172.31.111.229\\docs\\RC\\WorkFlowComercial\\" + seguimiento.OperacionID;
                        Directory.CreateDirectory(ruta);

                        foreach (var f in archivos)
                        {
                            string archivo = (seguimiento.SeguimientoID + "_" + f.FileName).ToLower();
                            f.SaveAs(Path.Combine(@ruta, Path.GetFileName(archivo)));

                            Documento documento = new Documento();
                            documento.SeguimientoID = seguimiento.SeguimientoID;
                            documento.NombreArchivo = archivo;
                            documento.Ruta = ruta;

                            db.Documento.Add(documento);
                            db.SaveChanges();
                        }

                    }

                    // Envio de correo electronico (alerta)
                    // Estado "3" = nueva operacion = ingreso a riesgos
                    // Estado "4" = asignacion a FFRR
                    // Estado "7" = inicio gestion de respuestas
                    // Estado "12" = resolucion de la operacion
                    
                        if (destinatarios != null)
                        {
                            //var mensajehtml = "<html>";
                            //mensajehtml += "<head><title>Work Flow Comercial</title></head>";
                            //mensajehtml += "<body>";
                            //mensajehtml += "<p>Existe un nuevo seguimiento pendiente para la Operación " + operacion.OperacionID.ToString() + ".</p>";
                            //mensajehtml += "<p><b>Cliente</b>: " + operacion.Cliente.Nombre + "<br>";
                            //mensajehtml += "<b>Estado</b>: " + operacion.Estado.Nombre + "<br>";
                            //mensajehtml += "<b>Remitente</b>: " + seguimiento.Usuario.Nombre + "</p>";
                            //mensajehtml += "<p>Ingrese al aplicativo preferentemente (por motivos de visualización) desde el navegador Chrome: http://172.31.111.229/WFComercial </p>";
                            //mensajehtml += "<br><p>Riesgos Comerciales<br>Banco de Crédito BCP</p>";
                            //mensajehtml += "</body>";
                            //mensajehtml += "</html>";

                            var mensajehtml = @"<html>   <head>   </head>   <body >      <div class=WordSection1>         <br>         <div align=center>
            <table  Table border=0 cellspacing=25 cellpadding=0 width=956               style='width:417.35pt;mso-cellspacing:15.7pt;background: #cf6f37 ;mso-yfti-tbllook:
               184;mso-padding-alt:0in 0in 0in 0in'>               <tr>                  <td>                     <div align=center>                        <table>
                           <tr>                              <td>                                 <p  ><b><i><span style='font-size:13.5pt; color:white'>Riesgos Comerciales</span></i></b></p>
                              </td>                              <td >                                 <p   align=right style='text-align:right'>
                                    <b><i><span                                       style='font-size:13.5pt; color:white'>Notificaci&oacute;n</span></i></b>
                                    <span>                                       <o:p></o:p>                                    </span>
                                 </p>                              </td>                           </tr>                           <tr>
                              <td width=866 colspan=2 style='width:649.3pt;background:white;padding:11.25pt 11.25pt 11.25pt 11.25pt;
                                 height:333.3pt'>
                                 <table  Table border=0 cellspacing=0 cellpadding=0
                                    align=left width=837 style='width:627.6pt;mso-cellspacing:0in;mso-yfti-tbllook:
                                    1184;mso-table-lspace:7.05pt;margin-left:4.8pt;mso-table-rspace:7.05pt;
                                    margin-right:4.8pt;mso-table-anchor-vertical:paragraph;mso-table-anchor-horizontal:
                                    column;mso-table-left:left;mso-padding-alt:0in 0in 0in 0in'>
                                    <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:74.5pt'>
                                       <td width='100%' style='width:100.0%;padding:0in 0in 0in 0in;height:74.5pt'>
                                          <p   align=center style='text-align:center'>
                                             <b><i><span
                                                style='font-size:26.0pt;color:#EA6B14;'>WorkFlow Riesgos Comerciales</span></i></b>
                                             <span
                                                lang=es-419 style='font-size:12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                    <tr style='mso-yfti-irow:1;height:17.75pt'>
                                       <td width='100%' style='width:100.0%;padding:0in 0in 0in 0in;height:17.75pt'>
                                          <p   style='margin-bottom:12.0pt'>
                                             <b><span  
                                                style='font-size:12.0pt; color:#1F497D;'>Estimad@s:</span></b><span  
                                                style='font-size:12.0pt; color:#1F497D;'>&nbsp;</span>
                                             <span style='font-size:
                                                12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                    <tr style='mso-yfti-irow:2;height:120.3pt'>
                                       <td width='100%' style='width:100.0%;padding:0in 0in 0in 0in;height:120.3pt'>
                                          <p   align=center style='margin-bottom:12.0pt;text-align:
                                             center'>
                                             <span   style='font-size:12.0pt; color:#1F497D;'>Existe un nuevo seguimiento pendiente con el siguiente detalle:</span>
                                             <span   style='font-size:12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                          <p   align=center style='margin-bottom:12.0pt;text-align:
                                             center'>
                                             <span style='color:#1F497D'>
                                                <o:p>&nbsp;</o:p>
                                             </span>
                                          </p>
                                          <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Cliente: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>" + operacion.Cliente.Nombre + @"</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
										  <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Estado: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>" + operacion.Estado.Nombre +  @"</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
										  <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Remitente: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>" + seguimiento.Usuario.Nombre + @"</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
										  <p style='margin-bottom:12.0pt'>
                                             <b><span
                                                style='color:#EA6B14'>Enlace: &nbsp;</span></b><span
                                                style='color:#1F497D;'>
                                             <span>http://172.31.111.229/WF_COMERCIAL/</span></span>
                                             <span
                                                style='color:#1F497D'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td width='100%' >
                                          <p   align=center style='margin-bottom:12.0pt;text-align:
                                             center'>
                                             <b><span>Laboratorio de Informacion de Riesgos - LIDeR</span></b><b><span><br>
                                             </span></b>
											 
											 <span style='color:#EA6B14;'>Internos</span><span style='color:#C55A11;'>&nbsp;</span>
											 <b><span style='color:#000060; '>:</span></b>
											 <span style='font-size:12.0pt;color:#1F497D;
                                                '>&nbsp;</span><span style='color:#EA6B14; '>2374</span><b><span style='color:navy; '>&nbsp;-</span></b><span
                                                style='color:#C55A11;'>&nbsp;</span><span style='color:#EA6B14; '>2278</span><span style='color:#C55A11;'>&nbsp;</span>
                                             <b><span style='color:navy; '>-&nbsp;</span></b><span style='color:#EA6B14;'>3374</span>
                                             <span lang=es-419
                                                style='font-size:12.0pt;'>
                                                <o:p></o:p>
                                             </span>
                                          </p>
                                       </td>
                                    </tr>
                                 </table>
                              </td>
                           </tr>
                        </table>
                        </br>
                     </div>
                  </td>
               </tr>
            </table>
         </div>
         <p>
            <span >
               <o:p>&nbsp;</o:p>
            </span>
         </p>
      </div>
   </body>
</html>
";

                            Sendmail(destinatarios, null, mensajehtml, null);
                        }
                    

                    return RedirectToAction("Index", "Operacion");
                }

                //ViewBag.OperacionID = new SelectList(db.Operacion, "OperacionID", "Tipo", seguimiento.OperacionID);
                //ViewBag.UsuarioID = new SelectList(db.Usuario, "UsuarioID", "Nombre", seguimiento.UsuarioID);

                return View(seguimiento);

            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create POST ", ex);
                return RedirectToAction("Index", "Operacion");
                throw;
            }
        }



        public ActionResult Disabled_op(int SeguimientoID, string Caso)
        {
            try
            {
                if (Caso == "SCONF")
                {
                    ViewBag.Conforme = "No se encuentra el correo de conformidad para realizar esta acción";
                }
                
                // Buscamos la operacion
                Operacion operacion = db.Seguimiento.Find(SeguimientoID).Operacion;
                ViewBag.estadoOperacion = operacion.EstadoID;

                // Creamos el nuevo seguimiento
                Seguimiento seguimiento = new Seguimiento();
                seguimiento.OperacionID = operacion.OperacionID;
                seguimiento.Operacion = operacion;
                seguimiento.Fecha = DateTime.Now;
                try
                {
                // Buscamos al usuario logueado para asignarlo como remitente
                    Usuario usuarioLogueado = db.Usuario.First(u => u.NombreUsuario == User.Identity.Name.ToUpper().Substring(7));
                    usuarioLogueado = db.Usuario.Find(id_user);
                    seguimiento.Usuario = usuarioLogueado;
                    seguimiento.UsuarioID = usuarioLogueado.UsuarioID;

                
                    // Buscamos ultimo seguimiento
                    Seguimiento ultimoSeguimiento = db.Seguimiento.Find(SeguimientoID);
                    seguimiento.Asunto = ultimoSeguimiento.Asunto;

                    seguimiento.Asunto = "Baja de Operación";
                    ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.NombreUsuario == usuarioLogueado.NombreUsuario), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                }
                catch (Exception ex)
                {
                    // Si es una nueva operacion
                    seguimiento.Asunto = "Baja de Operación";
                    ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Gerente de Negocios"), "UsuarioID", "Nombre");
                }

                return View(seguimiento);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create GET ", ex);
                return RedirectToAction("Index", "Operacion");
                throw;
            }
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Disabled_op([Bind(Include = "SeguimientoID,OperacionID,Fecha,UsuarioID,Asunto,Texto,PlazoVencimiento,lstDocumentos,rutaSharePoint,bool_envia_correo")] Seguimiento seguimiento, HttpPostedFileBase[] archivos, List<int> destinatarios, String estado, String tipo, List<int> destinatarioAdicional, String instancia, double? cem, String Caso)
        {
            try
            {
                int counter = 0;
                if (archivos[0] != null)
                {
                    foreach (var f in archivos)
                    {
                        string archivo = (f.FileName).ToLower();
                        string ext = Path.GetExtension(archivo);
                        if (ext.Contains("msg"))
                        {
                            counter++;
                        }
                    }
                }

                if (counter == 0)
                {
                    var _segid = (from a in db.Seguimiento
                                  where a.OperacionID == seguimiento.OperacionID
                                  select a).ToList();

                    int _seguimientoID = _segid.LastOrDefault().SeguimientoID;

                    return RedirectToAction("Disabled_op", "Seguimiento", new { SeguimientoID = _seguimientoID, Caso = "SCONF" });
                }

                GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Disabled_op " + seguimiento.SeguimientoID.ToString() + " - " + seguimiento.OperacionID.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                // Buscamos la operacion
                Operacion operacion = db.Operacion.Find(seguimiento.OperacionID);

                // Buscamos al usuario logueado 
                Usuario usuarioLogueado = db.Usuario.First(u => u.NombreUsuario == User.Identity.Name.ToUpper().Substring(7));
                usuarioLogueado = db.Usuario.Find(id_user);
                seguimiento.Usuario = usuarioLogueado;

                if (ModelState.IsValid)
                {

                    // Primero evaluamos los casos especiales
                    // El GN revisa al "Propuesta de Negocios" enviada por el FN                            

                        seguimiento.Asunto = "Baja de Operacion";

                        GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - BajaOperacion " + seguimiento.OperacionID.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                        int _operacionID = Convert.ToInt32(seguimiento.OperacionID);
                        int _ultimoEstado = 0;
                        string _fecha = DateTime.Now.ToString("yyyyMMdd", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                        var query = (from p in db.Operacion
                                        where p.OperacionID.Equals(_operacionID)
                                        select p).FirstOrDefault();
                        _ultimoEstado = query.EstadoID;

                        query.EstadoID = 20;
                        query.Fecha_Baja = _fecha;
                        query.Estado_Baja = _ultimoEstado;

                        db.SaveChanges();

                    // Guardamos los Destinatarios
                    if (destinatarios != null)
                    {
                        foreach (int i in destinatarios)
                        {
                            Usuario usuario = db.Usuario.Find(i);
                            seguimiento.Usuario1.Add(usuario);
                        }
                    }

                    // Guardamos el Seguimiento 
                    db.Seguimiento.Add(seguimiento);
                    db.SaveChanges();

                    // Guardamos documentos adjuntos
                    if (archivos[0] != null)
                    {

                        //string ruta = "d:\\\\WFComercialArchivos\\" + seguimiento.OperacionID;
                        string ruta = "\\\\172.31.111.229\\docs\\RC\\WorkFlowComercial\\" + seguimiento.OperacionID;
                        Directory.CreateDirectory(ruta);

                        foreach (var f in archivos)
                        {
                            string archivo = (seguimiento.SeguimientoID + "_" + f.FileName).ToLower();
                            f.SaveAs(Path.Combine(@ruta, Path.GetFileName(archivo)));

                            Documento documento = new Documento();
                            documento.SeguimientoID = seguimiento.SeguimientoID;
                            documento.NombreArchivo = archivo;
                            documento.Ruta = ruta;

                            db.Documento.Add(documento);
                            db.SaveChanges();
                        }

                    }
                    return RedirectToAction("Index", "Operacion");
                }

                return View(seguimiento);

            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create POST ", ex);
                return RedirectToAction("Index", "Operacion");
                throw;
            }
        }


        public ActionResult Activated_op(int SeguimientoID, string Caso)
        {
            try
            {
                if (Caso == "SCONF")
                {
                    ViewBag.Conforme = "No se encuentra el correo de conformidad para realizar esta acción";
                }
                
                var _segid = (from a in db.Seguimiento
                              where a.OperacionID == SeguimientoID
                              select a).ToList();

                int _seguimientoID = _segid.LastOrDefault().SeguimientoID;

                // Buscamos la operacion
                Operacion operacion = db.Seguimiento.Find(_seguimientoID).Operacion;
                ViewBag.estadoOperacion = operacion.EstadoID;

                // Creamos el nuevo seguimiento
                Seguimiento seguimiento = new Seguimiento();
                seguimiento.OperacionID = operacion.OperacionID;
                seguimiento.Operacion = operacion;
                seguimiento.Fecha = DateTime.Now;

                try
                {
                // Buscamos al usuario logueado para asignarlo como remitente
                    Usuario usuarioLogueado = db.Usuario.First(u => u.NombreUsuario == User.Identity.Name.ToUpper().Substring(7));
                    usuarioLogueado = db.Usuario.Find(id_user);
                    seguimiento.Usuario = usuarioLogueado;
                    seguimiento.UsuarioID = usuarioLogueado.UsuarioID;

                    // Buscamos ultimo seguimiento
                    Seguimiento ultimoSeguimiento = db.Seguimiento.Find(_seguimientoID);
                    seguimiento.Asunto = ultimoSeguimiento.Asunto;

                    seguimiento.Asunto = "Activacion de Operación";
                    ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.NombreUsuario == usuarioLogueado.NombreUsuario), "UsuarioID", "Nombre", new List<int> { ultimoSeguimiento.UsuarioID });
                }
                catch (Exception ex)
                {
                    // Si es una nueva operacion
                    seguimiento.Asunto = "Activacion de Operación";
                    ViewBag.ListaDestinatarios = new MultiSelectList(db.Usuario.Where(u => u.Cargo == "Gerente de Negocios"), "UsuarioID", "Nombre");
                }

                return View(seguimiento);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create GET ", ex);
                return RedirectToAction("Index", "Operacion");
                throw;
            }
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Activated_op([Bind(Include = "SeguimientoID,OperacionID,Fecha,UsuarioID,Asunto,Texto,PlazoVencimiento,lstDocumentos,rutaSharePoint,bool_envia_correo")] Seguimiento seguimiento, HttpPostedFileBase[] archivos, List<int> destinatarios, String estado, String tipo, List<int> destinatarioAdicional, String instancia, double? cem, String Caso)
        {
            try
            {
                int counter = 0;
                if (archivos[0] != null)
                {
                    foreach (var f in archivos)
                    {
                        string archivo = (f.FileName).ToLower();
                        string ext = Path.GetExtension(archivo);
                        if (ext.Contains("msg"))
                        {
                            counter++;
                        }
                    }
                }

                if (counter == 0)
                {
                    var _segid = (from a in db.Seguimiento
                                  where a.OperacionID == seguimiento.OperacionID
                                  select a).ToList();

                    int _seguimientoID = _segid.LastOrDefault().OperacionID;

                    return RedirectToAction("Activated_op", "Seguimiento", new { SeguimientoID = _seguimientoID, Caso = "SCONF" });
                }

                GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create " + seguimiento.SeguimientoID.ToString() + " - " + seguimiento.OperacionID.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                // Buscamos la operacion
                Operacion operacion = db.Operacion.Find(seguimiento.OperacionID);

                // Buscamos al usuario logueado 
                Usuario usuarioLogueado = db.Usuario.First(u => u.NombreUsuario == User.Identity.Name.ToUpper().Substring(7));
                usuarioLogueado = db.Usuario.Find(id_user);
                seguimiento.Usuario = usuarioLogueado;

                if (ModelState.IsValid)
                {

                    // Primero evaluamos los casos especiales
                    // El GN revisa al "Propuesta de Negocios" enviada por el FN                            

                    seguimiento.Asunto = "Activación de Operación";

                    GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Activavion de operacion " + seguimiento.OperacionID.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                    int _operacionID = Convert.ToInt32(seguimiento.OperacionID);
                    int _ultimoEstado = 0;
                    string _fecha = DateTime.Now.ToString("yyyyMMdd", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                    var query = (from p in db.Operacion
                                 where p.OperacionID.Equals(_operacionID)
                                 select p).FirstOrDefault();

                    _ultimoEstado = Convert.ToInt32(query.Estado_Baja);
                    query.EstadoID = _ultimoEstado;
                    query.Fecha_Baja = null;
                    query.Estado_Baja = null;

                    db.SaveChanges();

                    // Guardamos los Destinatarios
                    if (destinatarios != null)
                    {
                        foreach (int i in destinatarios)
                        {
                            Usuario usuario = db.Usuario.Find(i);
                            seguimiento.Usuario1.Add(usuario);
                        }
                    }

                    // Guardamos el Seguimiento 
                    db.Seguimiento.Add(seguimiento);
                    db.SaveChanges();

                    // Guardamos documentos adjuntos
                    if (archivos[0] != null)
                    {

                        //string ruta = "d:\\\\WFComercialArchivos\\" + seguimiento.OperacionID;
                        string ruta = "\\\\172.31.111.229\\docs\\RC\\WorkFlowComercial\\" + seguimiento.OperacionID;
                        Directory.CreateDirectory(ruta);

                        foreach (var f in archivos)
                        {
                            string archivo = (seguimiento.SeguimientoID + "_" + f.FileName).ToLower();
                            f.SaveAs(Path.Combine(@ruta, Path.GetFileName(archivo)));

                            Documento documento = new Documento();
                            documento.SeguimientoID = seguimiento.SeguimientoID;
                            documento.NombreArchivo = archivo;
                            documento.Ruta = ruta;

                            db.Documento.Add(documento);
                            db.SaveChanges();
                        }

                    }
                    return RedirectToAction("Index", "Operacion");
                }

                return View(seguimiento);

            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create POST ", ex);
                return RedirectToAction("Index", "Operacion");
                throw;
            }
        }


        //ENVIA OPERACION A RIESGOS, SIN PASAR POR GERENCIA DE NEGOCIOS
        public ActionResult EvaluacionRiesgos(int id)
        {
            try
            {
                GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - EvaluacionRiesgos " + id + " - " + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                // Buscamos la operacion
                Operacion operacion = db.Operacion.Find(id);

                // Buscamos al usuario logueado 
                Usuario usuarioLogueado = db.Usuario.First(u => u.NombreUsuario == User.Identity.Name.ToUpper().Substring(7));
                usuarioLogueado = db.Usuario.Find(id_user);

                Seguimiento seguimiento = new Seguimiento();

                seguimiento.Usuario = usuarioLogueado;

                // Actualizar "estado" de la operacion -> "(3) Nueva operacion"
                Estado estadoTable = db.Estado.First(e => e.EstadoID == 2);
                operacion.Estado = estadoTable;
                db.Entry(operacion).State = EntityState.Modified;
                db.SaveChanges();

                Usuario usuario = db.Usuario.Find(usuarioLogueado.UsuarioID);
                seguimiento.Usuario1.Add(usuario);

                seguimiento.Asunto = "Conforme Negocios";
                seguimiento.OperacionID = id;
                seguimiento.Operacion = operacion;
                seguimiento.Fecha = DateTime.Now;

                db.Seguimiento.Add(seguimiento);
                db.SaveChanges();   
                return RedirectToAction("Index", "Operacion");
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }


        // GET: /Seguimiento/Edit/5
        public ActionResult Edit(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Seguimiento seguimiento = db.Seguimiento.Find(id);
                if (seguimiento == null)
                {
                    return HttpNotFound();
                }
                ViewBag.OperacionID = new SelectList(db.Operacion, "OperacionID", "Tipo", seguimiento.OperacionID);
                ViewBag.UsuarioID = new SelectList(db.Usuario, "UsuarioID", "Nombre", seguimiento.UsuarioID);
                return View(seguimiento);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit GET ", ex);
                return RedirectToAction("Index", "Operacion");
                throw;
            }
        }

        // POST: /Seguimiento/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "SeguimientoID,OperacionID,Fecha,UsuarioID,Asunto,Texto,PlazoVencimiento")] Seguimiento seguimiento)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit " + seguimiento.SeguimientoID.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                    db.Entry(seguimiento).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                ViewBag.OperacionID = new SelectList(db.Operacion, "OperacionID", "Tipo", seguimiento.OperacionID);
                ViewBag.UsuarioID = new SelectList(db.Usuario, "UsuarioID", "Nombre", seguimiento.UsuarioID);
                return View(seguimiento);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit POST ", ex);
                return RedirectToAction("Index", "Operacion");
                throw;
            }
        }

        // GET: /Seguimiento/Delete/5
        public ActionResult Delete(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Seguimiento seguimiento = db.Seguimiento.Find(id);
                if (seguimiento == null)
                {
                    return HttpNotFound();
                }
                return View(seguimiento);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Delete GET ", ex);
                return RedirectToAction("Index", "Operacion");
                throw;
            }
        }

        // POST: /Seguimiento/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - DeleteConfirmed " + id.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                Seguimiento seguimiento = db.Seguimiento.Find(id);
                db.Seguimiento.Remove(seguimiento);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - DeleteConfirmed POST ", ex);
                return RedirectToAction("Index", "Operacion");
                throw;
            }
        }


        [HttpGet]
        public ActionResult CreaCarpeta(string nombre, string ruta)
        {
            try
            {
                string path = ruta + nombre;
                var credentials = new NetworkCredential(user_SP, pass_SP, "BTBNET");
                using (new NetworkConnection(Path.GetFullPath(Path.Combine(ruta, @"..\")), credentials))
                {
                    if (!System.IO.Directory.Exists(path))
                    {
                        System.IO.Directory.CreateDirectory(path);
                        return Content("</br>" + " <p class='alert alert-info'>    Se creo la carpeta " + nombre + "</p> </br>");
                    }
                    else
                    {
                        return Content("</br>" + " <p class='alert alert-danger'>    No se pudo crear la carpeta " + nombre + "</p> </br>");
                    }
                }
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - CreaCarpeta GET ", ex);
                return RedirectToAction("Index", "Operacion");
                throw;
            }
        }


        public void Sendmail(List<int> destinatarios, List<string> listAdicional, string mensajehtml, List<string> listfiles)
        {
            try
            {
                //SMTP host
                SmtpClient client = new SmtpClient("BTBEXC00.bancred.com.bo");

                // Correo Remitente - Nombre del Remitente
                MailMessage message = new MailMessage();
                message.From = new MailAddress("BolRiesgosComerciales@bancred.com.bo", "WF-Riesgos Comerciales", System.Text.Encoding.UTF8);

                message.Subject = "WorkFlow Comercial Notificación";
                message.Body = mensajehtml;
                message.IsBodyHtml = true;

                // Lista de destinatarios
                if (destinatarios != null)
                {
                    string user_v1 = System.Configuration.ConfigurationManager.AppSettings["user_v1"];
                    string user_v2 = System.Configuration.ConfigurationManager.AppSettings["user_v2"];

                    foreach (int i in destinatarios)
                    {
                        Usuario usuario = db.Usuario.Find(i);
                        //if (usuario.Matricula.ToString().ToUpper() == user_v1.ToUpper())
                        //{
                        //    message.To.Add(new MailAddress(user_v2 + "@bancred.com.bo"));
                        //    message.To.Add(new MailAddress(user_v2 + "@bcp.com.bo"));
                        //}
                        //else
                        //{
                            message.To.Add(new MailAddress(usuario.Matricula + "@bancred.com.bo"));
                            message.To.Add(new MailAddress(usuario.Matricula + "@bcp.com.bo"));
                        //}
                    }
                }

                // Lista de destinatarios adicional
                if (listAdicional != null)
                {
                    foreach (var i in listAdicional)
                    {
                        message.To.Add(i.ToString());
                    }
                }

                if (listfiles != null)
                {
                    foreach (var i in listfiles)
                    {
                        message.Attachments.Add(new Attachment(i.ToString()));
                    }
                }

                message.CC.Add("CCoria@bcp.com.bo");
                message.CC.Add("FCondoriR@bcp.com.bo");

                // Lista de todos los involucrados
                //foreach (int i in db.Usuario.Where(u => u.Seguimiento1.Any(s => s.OperacionID == operacion.OperacionID) && u.Matricula != "").Select(u => u.UsuarioID).Distinct().ToList())
                //{
                //    Usuario usuario = db.Usuario.Find(i);
                //    message.CC.Add(new MailAddress(usuario.Matricula + "@bancred.com.bo"));
                //}

                //client.Send(message);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Sendmail ", ex);
                throw;
            }
        }

        public void openFolder(string ruta)
        {
            try
            {
                var credentials = new NetworkCredential(user_SP, pass_SP, "BTBNET");
                using (new NetworkConnection(Path.GetFullPath(Path.Combine(ruta, @"..\..\")), credentials))
                {
                    GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - open folder 1 " + ruta.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                    
                    if (!System.IO.Directory.Exists(ruta))
                    {
                        System.IO.Directory.CreateDirectory(ruta);
                    }

                    Process.Start("explorer.exe", @ruta);
                    GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - open folder 2 " + ruta.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                    var startinfo = new ProcessStartInfo();

                    startinfo.LoadUserProfile = true;
                    startinfo.WorkingDirectory = ruta;
                    startinfo.UserName = "S69596";
                    startinfo.Domain = "BTBNET";
                    System.Security.SecureString secure = new System.Security.SecureString();
                    foreach (char c in pass_SP)
                    {
                        secure.AppendChar(c);
                    }
                    startinfo.Password = secure;
                    startinfo.UseShellExecute = false;
                    //Process.Start("explorer.exe", @ruta);
                    Process.Start("explorer.exe", startinfo.WorkingDirectory);

                    GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - open folder 3 " + ruta.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                }
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Open Folder ", ex);
                Process.Start("explorer.exe");
                //Process.Start(@"c:\");
            }
        }

        [HttpGet]
        public FileResult descargar(int id)
        {
            try
            {
                var doc = (from t1 in db.Documento
                           where (t1.DocumentoID == id)
                           select new { t1.Ruta, t1.NombreArchivo }).FirstOrDefault();
                string fullpath = doc.Ruta + "\\" + doc.NombreArchivo;
                if (!string.IsNullOrEmpty(id.ToString()))
                {
                    if (System.IO.File.Exists(fullpath))
                    {
                        byte[] fileBytes = System.IO.File.ReadAllBytes(fullpath);
                        string fileName = doc.NombreArchivo;
                        return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - descargar GET ", ex);
                return null;
                throw;
            }
        }


        [HttpPost]
        public ActionResult addDocs([Bind(Include = "SeguimientoID,OperacionID")] Seguimiento seguimiento, HttpPostedFileBase[] archivos)
        {
            try
            {
                if (archivos[0] != null)
                {

                    //string ruta = "d:\\\\WFComercialArchivos\\" + seguimiento.OperacionID;
                    string ruta = rutaRepositorio + seguimiento.OperacionID;
                    Directory.CreateDirectory(ruta);

                    foreach (var f in archivos)
                    {
                        string archivo = (seguimiento.SeguimientoID + "_" + f.FileName).ToLower();
                        f.SaveAs(Path.Combine(@ruta, Path.GetFileName(archivo)));

                        Documento documento = new Documento();
                        documento.SeguimientoID = seguimiento.SeguimientoID;
                        documento.NombreArchivo = archivo;
                        documento.Ruta = ruta;

                        db.Documento.Add(documento);
                        db.SaveChanges();
                    }

                }
                return RedirectToAction("Create", "Seguimiento", new { SeguimientoID=seguimiento.SeguimientoID });
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - adicion documentos ", ex);
                return RedirectToAction("Index", "Operacion");
                throw;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
