﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WFComercialWebApp.Models;
using Bitacora;
using NLog;

namespace WFComercialWebApp.Controllers
{
    public class DocumentoController : Controller
    {
        private RiesgosComercialesEntities db = new RiesgosComercialesEntities();

        // GET: /Documento/
        public ActionResult Index()
        {
            var documento = db.Documento.Include(d => d.Seguimiento);
            return View(documento.ToList());
        }

        public FileResult DownloadFile(int id)
        {
            try
            {
                Documento documento = db.Documento.Find(id);

                string contentType = "text/plain";

                if (documento.NombreArchivo.Contains(".csv"))
                {
                    contentType = "text/csv";
                }
                //else if (documento.NombreArchivo.Contains(".docx"))  
                //{  
                //    contentType = "application/docx";  
                //}
                else if (documento.NombreArchivo.Contains(".doc"))
                {
                    contentType = "application/msword";
                }
                else if (documento.NombreArchivo.Contains(".pdf"))
                {
                    contentType = "application/pdf";
                }
                else if (documento.NombreArchivo.Contains(".ppt"))
                {
                    contentType = "application/vnd.ms-powerpoint";
                }
                else if (documento.NombreArchivo.Contains(".rar"))
                {
                    contentType = "application/x-rar-compressed";
                }
                else if (documento.NombreArchivo.Contains(".rtf"))
                {
                    contentType = "application/rtf";
                }
                else if (documento.NombreArchivo.Contains(".vsd"))
                {
                    contentType = "application/vnd.visio";
                }
                else if (documento.NombreArchivo.Contains(".xls"))
                {
                    contentType = "application/vnd.ms-excel";
                }
                else if (documento.NombreArchivo.Contains(".xlsx"))
                {
                    contentType = "application/vnd.ms-excel";
                }
                else if (documento.NombreArchivo.Contains(".xlsm"))
                {
                    contentType = "application/vnd.ms-excel";
                }
                else if (documento.NombreArchivo.Contains(".zip"))
                {
                    contentType = "application/zip";
                }

                return File(documento.Ruta + "\\" + documento.NombreArchivo, contentType, documento.NombreArchivo);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - DownloadFile ", ex);
                return null;
                throw;
            }

        }

        // GET: /Documento/Details/5
        public ActionResult Details(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Documento documento = db.Documento.Find(id);
                if (documento == null)
                {
                    return HttpNotFound();
                }
                return View(documento);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Details ", ex);
                return null;
                throw;
            }
        }

        // GET: /Documento/Create
        public ActionResult Create()
        {
            ViewBag.SeguimientoID = new SelectList(db.Seguimiento, "SeguimientoID", "Asunto");
            return View();
        }

        // POST: /Documento/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "DocumentoID,SeguimientoID,NombreArchivo,Ruta")] Documento documento)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create " + documento.DocumentoID.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                    db.Documento.Add(documento);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                ViewBag.SeguimientoID = new SelectList(db.Seguimiento, "SeguimientoID", "Asunto", documento.SeguimientoID);
                return View(documento);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create POST ", ex);
                return null;
                throw;
            }
        }

        // GET: /Documento/Edit/5
        public ActionResult Edit(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Documento documento = db.Documento.Find(id);
                if (documento == null)
                {
                    return HttpNotFound();
                }
                ViewBag.SeguimientoID = new SelectList(db.Seguimiento, "SeguimientoID", "Asunto", documento.SeguimientoID);
                return View(documento);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit ", ex);
                return null;
                throw;
            }
        }

        // POST: /Documento/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "DocumentoID,SeguimientoID,NombreArchivo,Ruta")] Documento documento)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit " + documento.DocumentoID.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                    db.Entry(documento).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                ViewBag.SeguimientoID = new SelectList(db.Seguimiento, "SeguimientoID", "Asunto", documento.SeguimientoID);
                return View(documento);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit POST ", ex);
                return null;
                throw;
            }
        }

        // GET: /Documento/Delete/5
        public ActionResult Delete(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Documento documento = db.Documento.Find(id);
                if (documento == null)
                {
                    return HttpNotFound();
                }
                return View(documento);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Delete ", ex);
                return null;
                throw;
            }
        }

        // POST: /Documento/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - DeleteConfirmed " + id.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                Documento documento = db.Documento.Find(id);
                db.Documento.Remove(documento);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - DeleteConfirmed POST ", ex);
                return null;
                throw;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
