﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WFComercialWebApp.Models;
using Bitacora;
using NLog;

namespace WFComercialWebApp.Controllers
{
    public class EstadoController : Controller
    {
        private RiesgosComercialesEntities db = new RiesgosComercialesEntities();

        // GET: /Estado/
        public ActionResult Index()
        {
            var estado = db.Estado.Include(e => e.Instancia);
            return View(estado.ToList());
        }

        // GET: /Estado/Details/5
        public ActionResult Details(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Estado estado = db.Estado.Find(id);
                if (estado == null)
                {
                    return HttpNotFound();
                }
                return View(estado);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Details GET ", ex);
                return null;
                throw;
            }
        }

        // GET: /Estado/Create
        public ActionResult Create()
        {
            ViewBag.InstanciaID = new SelectList(db.Instancia, "InstanciaID", "Nombre");
            return View();
        }

        // POST: /Estado/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "EstadoID,Nombre,InstanciaID,FechaRegistro")] Estado estado)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create " + estado.EstadoID.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                    db.Estado.Add(estado);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                ViewBag.InstanciaID = new SelectList(db.Instancia, "InstanciaID", "Nombre", estado.InstanciaID);
                return View(estado);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create POST ", ex);
                return null;
                throw;
            }
        }

        // GET: /Estado/Edit/5
        public ActionResult Edit(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Estado estado = db.Estado.Find(id);
                if (estado == null)
                {
                    return HttpNotFound();
                }
                ViewBag.InstanciaID = new SelectList(db.Instancia, "InstanciaID", "Nombre", estado.InstanciaID);
                return View(estado);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit GET ", ex);
                return null;
                throw;
            }
        }

        // POST: /Estado/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "EstadoID,Nombre,InstanciaID,FechaRegistro")] Estado estado)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit " + estado.EstadoID.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                    db.Entry(estado).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                ViewBag.InstanciaID = new SelectList(db.Instancia, "InstanciaID", "Nombre", estado.InstanciaID);
                return View(estado);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit POST ", ex);
                return null;
                throw;
            }
        }

        // GET: /Estado/Delete/5
        public ActionResult Delete(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Estado estado = db.Estado.Find(id);
                if (estado == null)
                {
                    return HttpNotFound();
                }
                return View(estado);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Delete GET ", ex);
                return null;
                throw;
            }
        }

        // POST: /Estado/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - DeleteConfirmed " + id.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                Estado estado = db.Estado.Find(id);
                db.Estado.Remove(estado);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - DeleteConfirmed POST ", ex);
                return null;
                throw;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
